# Consolidated depth-three proof note and trace-sign bound

7 October 2026. This document combines the updated family-recognition note and the new sign-bound appendix for standalone human review. The proofs remain unrefereed, and no novelty or benchmark claim is made. Code, exact certificates, source hashes, historical reports and the research ledger are in the accompanying handover.

# Direct recognition of one depth-three family: the ordinary j=0 seed at conductor 8

7 October 2026. Separate unrefereed extension note for the Cartier–Miller evaluation project. The published manuscript is unchanged; the repository URL and commit remain unknown and GitHub has not been inspected. The note distinguishes algebraic derivations, which require human review, from executable identities checked in finite fields, and from deferred or conjectural material. No novelty or wall-time benchmark is claimed. A second, independent worker re-derived every constant, attacked the implementation and verified the literature before this version was written; its report is retained under `independent/` and its criticisms are reconciled in the penultimate section.

Consolidated 7 October 2026. The trace-sign trial-count gap is now addressed in the trace-sign appendix below, including exact small-prime certificates and a preserved counterexample outside this family. Current code and fresh validation supersede the historical API descriptions in the retained independent-worker report. The published manuscript is unchanged.

## Outcome in one paragraph

Starting from the retained modulo-73 target, the depth-three nondual closure of the ordinary easy seed $A=0$ is a single explicit family over the biquadratic field $\mathbb Q(\sqrt2,\sqrt3)$, parametrized by a nonzero twist parameter $r$ together with a choice of signs $e=\pm\sqrt3$, $g=\pm\sqrt2$, with short coefficients $A=\alpha(e,g)r^2$, $B=\gamma(e,g)r^3$ and second-kind coefficient $\beta=-(7+6e+6g+2eg)\,rH$. Its kernel roots are rational and its seed ordinary precisely when $p\equiv1\pmod{24}$. The four conjugate $j$-invariants are the roots of the classical class polynomial of discriminant $-192$. A direct recognizer extracts $e$ and $g$ from the supplied coefficients $(A,B)$ by two relative norms in $\mathbb F_p[e,g]/(e^2-3,g^2-2)$, then $r$, and verifies both coefficient equations together with the forward and reverse rooted paths; it uses a constant number of field operations, no square-root algorithm and no graph search. Exact integer factorizations show that at every eligible prime the extraction denominators are nonzero for every family member, the models are nonsingular, the conjugates are distinct, and no collision with any depth-at-most-two class or with the other depth-three chain occurs. Every quadratic twist is absorbed by $r\mapsto dr$. The exact trace of an accepted curve is not an independent unknown: it equals the trace of its $j=0$ seed and is $\pm t_0$ for the unique representation $4p=t_0^2+192f^2$, so a complete preparation needs a Cornacchia representation and one sign bit rather than general point counting. The consolidated sign bound gives at most five raw uniform-x trials in expectation for the unbounded zero-error version; the default 64-trial attempt may return an inconclusive status. The missing coefficient $K$ of the original normalized cubic then follows in constant field work. The companion depth-three chain from the $B=0$ seed is deferred: its class field is dihedral rather than biquadratic and needs a different extraction.

| Claim | Evidence category | Status |
|---|---|---|
| Family coefficients, kernel roots and $\beta$ multiplier | Symbolic derivation from the retained normalized quotient, re-derived by hand, by two scripts of the first worker and by the independent worker's own ring arithmetic | Unrefereed algebraic proof |
| Retained transport identities (curve equation, scale $+1$, exact correction, dual scaling) | Independent symbolic re-check in this pass; independent worker's own proof and 2,292 exact tests | Rational-function identities verified; Cartier step argued below |
| Rationality and ordinarity condition $p\equiv1\pmod{24}$ | Elementary quadratic-character argument | Proved |
| Direct recognition, soundness and completeness at eligible primes | Relative-norm extraction plus exact integer norms of the collision elements | Unrefereed algebraic proof |
| Disjointness from every depth-at-most-two class and from the $B=0$ depth-three chain at eligible primes | Exact evaluations and resultants of the class polynomial | Proved by integer factorization; also forced by CM theory |
| Identification with the class polynomial of discriminant $-192$ | PARI `polclass`, Lario's table, and two independent eliminations | Verified computationally; classical, not new |
| Completeness as the whole nondual depth-three $A=0$-seed closure | Cofactor lemma; exhaustive finite comparison at ten primes | Proved, with finite support |
| Trace of an accepted curve is $\pm t_0$, $4p=t_0^2+192f^2$ unique | Cartier transport, the seed's CM by $\mathbb Z[\omega]$, and Kohel's volcano structure theorem as stated by Sutherland | Proved modulo one cited classical theorem |
| Complete preparation without general point counting | Cornacchia plus a zero-error sign test and consolidated proper-subgroup proof | Unbounded version has at most five raw trials in expectation; capped version may be inconclusive |
| Depth-three chain from the $B=0$ seed | Rationality condition derived; $j$-values lie on $H_{-256}$ at $p=73$ | Deferred; recognition not attempted |
| Generic or supersingular $K$ recovery | No new algorithm | Unresolved |

## Normalized data and the transport step

Let $p\ge7$ be prime and $E:y^2=F(x)=x^3+Ax+B$ nonsingular over $\mathbb F_p$, $h=(p-1)/2$, $H=[x^{p-1}]F^h$, $\beta=[x^{p-2}]F^h$, $\omega=dx/y$, $\eta=x\omega$. The absolute Cartier operator satisfies $C(\omega)=H\omega$ and $C(\eta)=\beta\omega$ (Katz, Section 1), and $H\equiv\tau\pmod p$ for the exact trace $\tau$. The easy seed used here is $A=0$ with $p\equiv1\pmod3$: every exponent of $(x^3+B)^h$ is a multiple of three while $p-2$ is not, so $\beta=0$, and $H=\binom{h}{(p-1)/3}B^{h-(p-1)/3}$ is a nonzero binomial coefficient with arguments below $p$ times a nonzero constant, so the seed is ordinary.

For a rational root $q$ of $F$ the retained explicitly normalized quotient is
$$A'=-4A-15q^2,\qquad B'=-8Aq-22q^3,\qquad \phi^*\omega'=\omega,\qquad \phi^*\eta'=(2x-q)\,\omega-2\,d\!\left(\frac{y}{x-q}\right).$$
Because this note relies on it three times in succession, the identities were re-derived in this pass rather than imported. With $u=A+3q^2=F'(q)$ the point map $x'=x+u/(x-q)$, $y'=y\bigl(1-u/(x-q)^2\bigr)$ satisfies $y'^2=x'^3+A'x'+B'$ modulo $y^2=F(x)$; its differential is $dx'/y'=dx/y$ exactly; and since $d(y/(x-q))=\bigl(F'(x)(x-q)-2F(x)\bigr)/(2(x-q)^2)\cdot\omega$ one has $x'\omega=(2x-q)\omega-2\,d(y/(x-q))$ as rational functions. These three facts are verified as exact rational-function identities by `theory/verify_transport.py`, and the independent worker proved them again from Vélu's form of the map. The Cartier step is the standard one: the quotient is separable because $p$ is odd, so a separating variable of the target function field remains a separating variable of the source, the unique $p$-basis decomposition is preserved, and $C$ commutes with $\phi^*$; exact differentials are killed. Hence $H'=H$ and $\beta'=2\beta-qH$, with differential scale $+1$ on every edge and no local-principal-part substitution. The same script confirms that the distinguished dual root $-2q$ of the target returns $(16A,64B)$, the square scaling $d=4$, and proves the cofactor lemma used below: on the target, $x^3+A'x+B'=(x+2q)\bigl(x^2-2qx+(A'+4q^2)\bigr)$ and the quadratic cofactor has discriminant $16F'(q)$, so the two nondual roots of the target are
$$q\pm2\sqrt{F'(q)}=q\pm2\sqrt{A+3q^2}.$$
This lemma determines every nondual continuation of a rooted chain from the data of the previous edge alone.

## The family

Fix the seed $E_0:(0,-r^3)$ with $r\ne0$; every $A=0$ model with a rational two-torsion point has this form, because $x^3+B$ has a rational root exactly when $-B$ is a cube. At $p\equiv1\pmod3$ the seed has three rational roots $r,\omega r,\omega^2r$ with $\omega$ a primitive cube root of unity; the chain started at $\omega r$ is the chain of the same seed written as $(0,-(\omega r)^3)$ with parameter $\omega r$, so letting $r$ range over all of $\mathbb F_p^\times$ absorbs this choice and nothing below depends on which root is called $r$. The first kernel root is $q_0=r$, giving $E_1:(-15r^2,-22r^3)$ and $\beta_1=-rH$. The cofactor lemma with $F_0'(r)=3r^2$ gives the nondual roots $q_1=(1\pm2e)r$ with $e^2=3$; the retained depth-two family $E_2:\bigl((-135-60e)r^2,(-694-420e)r^3\bigr)$, $\beta_2=-(3+2e)rH$, follows. The new step applies the lemma once more. Here $F_1'(q_1)=A_1+3q_1^2=\bigl(-15+3(13+4e)\bigr)r^2=12(2+e)r^2$, and since $(3+e)^2\cdot2=24+12e$ one has $\sqrt{12(2+e)}=(3+e)g$ with $g^2=2$. Therefore the nondual third kernel roots are
$$q_2=\bigl(1+2e\pm2(3+e)g\bigr)r=(1+2e+6g+2eg)\,r,$$
the sign being absorbed into the choice of $g$. Substituting into the quotient gives the family
$$\boxed{A=\alpha(e,g)\,r^2,\quad B=\gamma(e,g)\,r^3,\qquad
\alpha=-1095-540e-540g-420eg,\quad
\gamma=-22198-13860e-16380g-8820eg,}$$
and the transport $\beta_3=2\beta_2-q_2H$ gives
$$\boxed{\beta=-(7+6e+6g+2eg)\,rH.}$$
The coordinates were obtained by hand, by a sympy script in $\mathbb Z[e,g]/(e^2-3,g^2-2)$, by a standard-library integer script that re-runs the three quotients from the seed, and by the independent worker's own ring arithmetic; all agree. The chain is nondual at each step: $q_1=-2q_0$ would force $3=0$, and $q_2=-2q_1$ would force $3+6e+6g+2eg=0$, whose norm to $\mathbb Q$ is $9$. The two nondual third roots are distinct because $(3+e)g$ has norm $144$.

The reverse certificate is the dual chain. With $q_i$ the forward roots the inverse normalized roots are $-2\cdot4^iq_{2-i}$, that is
$$(-2q_2,\,-8q_1,\,-32q_0)=\bigl(-(2+4e+12g+4eg)r,\;-(8+16e)r,\;-32r\bigr),$$
and the endpoint is the seed scaled by $d=4^3$, namely $(0,-(64r)^3)$, which is again an $A=0$ seed. The reverse multiplier $\sum_i q^{\rm rev}_i/2^{i+1}=-q_2-2q_1-4q_0$ equals $-(7+6e+6g+2eg)r$ without any division by $H$, in agreement with the forward transport. At $p=73$ with $(e,g,r)=(21,41,42)$ this reproduces the retained fixture exactly: forward roots $(42,54,1)$, models $(0,7)\to(39,8)\to(50,22)\to(4,16)$, reverse roots $(71,6,43)$, endpoint $(0,7)$ and multiplier $15$, so that $\beta=15\cdot10=4$.

## Field of definition, ordinary primes and completeness of the closure

The kernel roots lie in $\mathbb F_p$ exactly when $e$ and $g$ do, which by the quadratic characters of $3$ and $2$ means $p\equiv\pm1\pmod{12}$ and $p\equiv\pm1\pmod8$. The seed is ordinary when $p\equiv1\pmod3$. Together these force $p\equiv1\pmod{24}$, and conversely every such prime admits the full construction with all four sign choices of $(e,g)$ and every nonzero $r$. The coefficients $\alpha,\gamma$ are also rational at $p\equiv23\pmod{24}$, where both square roots exist, but there the seed is supersingular and the construction is outside the ordinary scope; the eligibility condition is the conjunction of rationality and ordinarity. The smallest eligible prime is $73$, which is why the retained audit found its first depth-three $A=0$-seed classes there. At $p\equiv13\pmod{24}$ the depth-two family exists but, since $12(2+e)=2(3+e)^2$ is then a nonsquare, no rational nondual third step exists at all; this is an exact obstruction, not a search miss. In fact more is true and consistent with CM theory: at such primes $H_{-192}$ has no root modulo $p$ at all, because a root would give an ordinary curve whose Frobenius has norm $p$ in the order of discriminant $-192$, forcing $p=x^2+48y^2\equiv1\pmod8$; the independent worker verified the absence of roots at $13,37,61,109,157,181$. This remark is not used below.

The construction is also exhaustive. Any rooted chain of length three from an $A=0$ seed with no immediate dual step must take the displayed form: the seed must be $(0,-r^3)$ for one of its three roots $r$, the first quotient is then determined, and the cofactor lemma leaves only the displayed nondual roots at the second and third steps. Hence for $p\equiv1\pmod{24}$ the set of endpoints of nondual rational degree-two chains of length three from $A=0$ seeds is exactly
$$\mathcal F_3(p)=\{(\alpha(e,g)r^2,\gamma(e,g)r^3):\ e^2=3,\ g^2=2,\ r\in\mathbb F_p^\times\},$$
which has $4(p-1)$ distinct models, while for $p\equiv13\pmod{24}$ this set is empty. The parameters are injective on $\mathcal F_3(p)$ at eligible primes by the uniqueness statement of the recognition theorem below. The validation suite compares $\mathcal F_3(p)$ with an independent brute-force enumeration of all nondual length-three chains from every $(0,B)$ at ten eligible primes and finds equality in each case.

The minimal polynomial of $j=6912\alpha^3/(4\alpha^3+27\gamma^2)$ over $\mathbb Q$, obtained by multiplying the four conjugate linear factors in $\mathbb Z[e,g]$ and dividing by the norm of the discriminant, is
$$H_{-192}(J)=J^4-8041801037378436000\,J^3+15705521635909735050750000\,J^2+826335556188178615474500000000\,J-1080060886113159937649308593750000.$$
PARI's `polclass(-192)` returns the same polynomial, its Galois group is the Klein four-group, and Lario's author-curated table lists it for $D=-192$ with $\mathbb Q(j)=\mathbb Q(\sqrt2,\sqrt3)$. This is the expected position on the $2$-isogeny volcano descending from $j=0$: the seed has conductor $1$, and depths one, two and three have conductors $2$, $4$ and $8$ in $\mathbb Z[\omega]$, discriminants $-12$, $-48$ and $-192$. The identification is a verified consistency check and the curves and polynomial are classical; it is used below only through Kohel's structure theorem, in the trace section.

## Direct recognition

Let $R=\mathbb F_p[e,g]/(e^2-3,g^2-2)$ with basis $(1,e,g,eg)$. When $p\equiv1\pmod{24}$ and $(e_0,g_0)$ are fixed square roots of $3$ and $2$, the four ring homomorphisms $\chi_{s,t}:R\to\mathbb F_p$, $\chi_{s,t}(e,g)=(se_0,tg_0)$, identify $R$ with $\mathbb F_p^4$. Reduce the integer powers
$$\alpha^3=a_0+a_1e+a_2g+a_3eg,\qquad \gamma^2=c_0+c_1e+c_2g+c_3eg,$$
whose exact coordinates are in the table below. Given short coefficients $(A,B)$ with $AB\ne0$, form
$$L=B^2\alpha^3-A^3\gamma^2=U_0+U_1e+U_2g+U_3eg,\qquad U_i=B^2a_i-A^3c_i,$$
and the two relative norms
$$L\,\sigma_g(L)=P_0+P_1e,\qquad P_0=U_0^2+3U_1^2-2U_2^2-6U_3^2,\quad P_1=2(U_0U_1-2U_2U_3),$$
$$L\,\sigma_e(L)=Q_0+Q_1g,\qquad Q_0=U_0^2-3U_1^2+2U_2^2-6U_3^2,\quad Q_1=2(U_0U_2-3U_1U_3),$$
where $\sigma_e$ and $\sigma_g$ negate $e$ and $g$ respectively. The recognizer requires $P_1Q_1\ne0$ and sets
$$\boxed{e=-P_0/P_1,\qquad g=-Q_0/Q_1,\qquad r=\frac{\alpha(e,g)\,B}{\gamma(e,g)\,A},}$$
then checks $e^2=3$, $g^2=2$, $r\ne0$, $A=\alpha(e,g)r^2$, $B=\gamma(e,g)r^3$, and finally re-executes the forward chain from $(0,-r^3)$ and the reverse chain to $(0,-(64r)^3)$ with the retained path checker. It never computes a square root, never searches the isogeny graph, and never divides by $H$.

| Quantity | Coordinates in the basis $(1,e,g,eg)$ |
|---|---|
| $\alpha$ | $(-1095,\ -540,\ -540,\ -420)$ |
| $\gamma$ | $(-22198,\ -13860,\ -16380,\ -8820)$ |
| $\beta/(rH)$ | $(-7,\ -6,\ -6,\ -2)$ |
| $\alpha^3$ | $(-13988298375,\ -8054356500,\ -9859360500,\ -5708191500)$ |
| $\gamma^2$ | $(2072413204,\ 1193214960,\ 1460677680,\ 845626320)$ |
| $4\alpha^3+27\gamma^2$ | $(1963008,\ -622080,\ 855360,\ -855360)$ |
| forward roots $q_0,q_1,q_2$ over $r$ | $(1,0,0,0)$, $(1,2,0,0)$, $(1,2,6,2)$ |
| reverse roots over $r$ | $(-2,-4,-12,-4)$, $(-8,-16,0,0)$, $(-32,0,0,0)$ |

**Theorem (recognition).** Let $p\equiv1\pmod{24}$ and let $(A,B)$ be a nonsingular short model. If the recognizer accepts, then $(A,B)\in\mathcal F_3(p)$ with the exhibited parameters and $\beta(A,B)=-(7+6e+6g+2eg)\,rH$. Conversely every $(A,B)\in\mathcal F_3(p)$ is accepted, its parameters $(e,g,r)$ are uniquely determined by $(A,B)$, and $AB\ne0$.

Soundness is immediate: acceptance means the parameter equations hold, so $(A,B)$ is literally the endpoint of the displayed chain, which the certificate re-executes, and the coefficient identity is the transport statement of the previous section. For completeness let $(A,B)=(\alpha_0r_0^2,\gamma_0r_0^3)$ with $\alpha_0=\chi_0(\alpha)$, $\gamma_0=\chi_0(\gamma)$ for one character $\chi_0$. Then $L=r_0^6(\gamma_0^2\alpha^3-\alpha_0^3\gamma^2)$ as an element of $R$, so $\chi_0(L)=0$. For an automorphism $\sigma$ put $C_\sigma=\gamma^2\sigma(\alpha)^3-\alpha^3\sigma(\gamma)^2\in\mathbb Z[e,g]$; then $\chi_0\sigma(L)=r_0^6\chi_0(C_\sigma)$. Applying $\chi_0$ to $L\sigma_g(L)=P_0+P_1e$ gives $P_0+P_1e_0=\chi_0(L)\chi_0\sigma_g(L)=0$, and applying $\chi_0\sigma_e$ gives $P_0-P_1e_0=r_0^{12}\chi_0(C_{\sigma_e})\chi_0(C_{\sigma_e\sigma_g})$. Hence
$$P_1=-\frac{r_0^{12}\,\chi_0(C_{\sigma_e})\,\chi_0(C_{\sigma_e\sigma_g})}{2e_0},\qquad
Q_1=-\frac{r_0^{12}\,\chi_0(C_{\sigma_g})\,\chi_0(C_{\sigma_e\sigma_g})}{2g_0},$$
the second by the same argument with the roles of $e$ and $g$ exchanged. The integer norm $N(C_\sigma)$ reduces modulo $p$ to the product of the four values $\chi(C_\sigma)$, so if $p\nmid N(C_\sigma)$ then every $\chi_0(C_\sigma)$ is nonzero. The factorizations below show that no prime $p\equiv1\pmod{24}$ divides any of the three norms; therefore $P_1Q_1\ne0$, $e=-P_0/P_1=e_0$ and $g=-Q_0/Q_1=g_0$. Since no eligible prime divides $N(\alpha)N(\gamma)$, $\alpha_0\gamma_0\ne0$, so $r=\alpha_0B/(\gamma_0A)=r_0$ and both coefficient equations hold. Uniqueness follows because $e$, $g$ and $r$ are given by these explicit formulas in $(A,B)$. The vanishing of $\chi_0(C_\sigma)$ is exactly the coincidence $j_{\chi_0}=j_{\chi_0\sigma}$ in $\mathbb F_p$, because $j-\sigma(j)=-6912\cdot27\,C_\sigma/(\Delta\,\sigma(\Delta))$ with $\Delta=4\alpha^3+27\gamma^2$; so the theorem can be read as saying that at eligible primes the four conjugate $j$-values are distinct and the input's $j$ selects its conjugate, after which $r$ restores the coordinate factor that a $j$-only test would lose. The equivalent linear-algebra formulation is that the row vector $(1,e_0,g_0,e_0g_0)$ spans the kernel of the $4\times4$ multiplication-by-$L$ matrix; the relative norms are its closed form. For inputs outside the family the denominators $P_1$ or $Q_1$ can vanish; the independent worker showed these inputs are exactly the twists of two $j$-values per prime, roots of fixed integer quadratics in $B^2/A^3$, and all of them are correctly rejected.

## Exceptional primes, twists and collisions

All integers below were computed by sympy in $\mathbb Z[e,g]$, by a standard-library script with trial-division factorization and an explicit cofactor-equals-one assertion (`theory/check_integer_invariants_depth3.py`), and independently by the second worker; the three agree value for value. For an element $x$ of $\mathbb Z[e,g]$, $N(x)$ denotes the product of its four conjugates.

| Quantity | Factorization | Prime factors $\ge7$ reduced modulo $24$ |
|---|---|---|
| $N(\alpha)$ | $-3^4\,5^4\,11^2\,17^2\,23$ | $11,17,23$ |
| $N(\gamma)$ | $2^4\,11^2\,23^2\cdot47\cdot71\cdot167\cdot191$ | $11,23,23,23,23,23$ |
| $N(4\alpha^3+27\gamma^2)$ | $2^{28}\,3^{12}$ | none |
| $N(C_{\sigma_e})$ | $2^{30}3^{22}5^{12}17^8\,23^4\,41^4\,89^2\,113^2$ | $17,23,17,17,17$ |
| $N(C_{\sigma_g})$ | $2^{32}3^{20}5^{12}11^{10}59^4\,83^2\,131^2\,179^2$ | $11,11,11,11,11$ |
| $N(C_{\sigma_e\sigma_g})$ | $2^{30}3^{20}5^{14}29^4\,53^2\,101^4\,149^2\,173^2$ | $5,5,5,5,5$ |
| $H_{-192}(0)$ | $-2^4\,3^{12}5^{12}11^6\,17^6\,23^3$ | $11,17,23$ |
| $H_{-192}(1728)$ | $2^4\,3^{12}11^4\,23^4\,47^2\,71^2\,167^2\,191^2$ | $11,23,23,23,23,23$ |
| $H_{-192}(54000)$ | $2^4\,3^{20}5^{12}11^4\,17^2\cdot23\cdot29^2\,41^2\cdot47$ | $11,17,23,5,17,23$ |
| $H_{-192}(287496)$ | $2^4\,3^{12}11^6\cdot23\cdot47\cdot59^2\cdot239\cdot479\cdot599\cdot647\cdot719\cdot743$ | $11,23,23,11,23,23,23,23,23,23$ |
| $\mathrm{Res}(H_{-192},P_2)$ | $2^8\,3^{24}11^8\,23^4\cdot47\cdot71\cdot83^2\,107^2\,131^2\cdot167\cdot191\cdot227^2\cdot263\cdot863\cdot1223\cdot1847\cdot2111\cdot2447\cdot2543\cdot2711\cdot2903\cdot3023$ | all in $\{11,23\}$ |
| $\mathrm{Res}(H_{-192},P_3)$ | $-2^8\,3^{24}5^{24}11^{10}17^4\,23^5\,29^4\,47^3\,53^2\,59^2\cdot71\cdot83^2\,89^2$ | all in $\{5,11,17,23\}$ |
| $\mathrm{Res}(H_{-192},H_{-256})$ | $2^{12}3^{48}11^{20}23^{10}47^4\,59^4\,71^3\,83^2\,107^2\,179^2\cdot239\cdot251^2\cdot479\cdot599\cdot647\cdot659^2\cdot719\cdot743\cdot839\cdot2087\cdot2879\cdot4007\cdot5399\cdot6047\cdot6359\cdot6959\cdot7247\cdot8807\cdot9479\cdot9887\cdot10079\cdot10607\cdot11447\cdot11927\cdot12119\cdot12239\cdot12263$ | all in $\{11,23\}$ |
| $\mathrm{disc}(H_{-192})$ | $2^{20}3^{62}5^{38}11^{10}17^8\,23^4\,29^4\,41^4\,53^2\,59^4\,83^2\,89^2\,101^4\,113^2\,131^2\,149^2\,173^2\,179^2$ | all in $\{5,11,17,23\}$ |

Here $P_2$ and $P_3$ are the retained depth-two class polynomials of discriminants $-64$ and $-48$; $0$, $1728$, $54000$, $287496$ are the $j$-values of the seeds and the one-step families; and $H_{-256}$ is PARI's `polclass(-256)`, the class polynomial of the depth-three chain below $j=1728$. No prime factor is congruent to $1$ modulo $24$. Consequently, at every eligible prime, $\alpha$ and $\gamma$ are nonzero for all four conjugates, every family model is nonsingular, the four conjugate $j$-values are pairwise distinct, the extraction denominators $P_1$ and $Q_1$ are nonzero for every family member, and no family $j$-value equals any $j$-value of the complete depth-at-most-two closure or of the $B=0$ depth-three chain. Since at eligible primes that closure consists of every curve whose $j$ lies in its $j$-set, including all twists, and since $\mathcal F_3(p)$ likewise contains both quadratic twists of each of its $j$-values, the family is disjoint from the depth-at-most-two closure as a set of models, not merely as a set of $j$-values. These are global factorization statements, not extrapolations from the finite census. They are also what classical CM theory predicts: an ordinary curve with $j$ a root of $H_{-192}$ has endomorphism ring of discriminant $-192$ by Deuring's reduction theorem, so it cannot share a $j$-value with a curve of discriminant $-3$, $-12$, $-48$, $-4$, $-16$, $-64$ or $-256$, and the four conjugates are distinct at primes splitting completely in the ring class field. The residue pattern in the table is the same statement seen prime by prime: $j_\chi=j_{\chi\sigma_e}$ happens only at $p\equiv17\pmod{24}$, where $\sqrt2$ is rational and $\sqrt3$ is not, and similarly $11$ for $\sigma_g$ and $5$ for the composite. The factorizations are kept as the self-contained proof because they do not depend on any theorem that was not reopened in a primary source.

Degenerations are real outside the eligible class and are preserved rather than hidden. At $p\in\{23,47,71,167,191\}$, all congruent to $23$ modulo $24$, both square roots exist but the seed is supersingular; at $47,71,167,191$ exactly one of the four sign choices has $\gamma\equiv0$, collapsing that conjugate to $j=1728$, while at $p=23$ two sign choices have $\gamma\equiv0$ and a third has $\alpha\equiv0$, collapsing to $j=0$, as the exponents $23^2$ in $N(\gamma)$ and $23^1$ in $N(\alpha)$ predict. The recognizer reports `not_eligible_prime` for every input at such primes instead of applying the ordinary reconstruction. At the collision primes $29,41,53,59,83,89,101,113,131,149,173,179$ at least one of $\sqrt2,\sqrt3$ is irrational, so no base-field parameter model exists at all, and the coincidence is between non-rational conjugates. The validation suite records, for every tested excluded prime, the number of rational-parameter models and how many have $\alpha$, $\gamma$ or the discriminant equal to zero.

A displayed quadratic twist $d\ne0$ sends $(A,B)$ to $(d^2A,d^3B)$, $H$ to $\chi(d)H$ and $\beta$ to $d\chi(d)\beta$ by the retained polynomial identity $F_d(x)=d^3F(x/d)$. In the family this is exactly $r\mapsto dr$ with $(e,g)$ unchanged, and the multiplier becomes $d\cdot(-(7+6e+6g+2eg)r)$, so $\beta_d=d\,\chi(d)\,\beta$ is reproduced without computing $\chi(d)$: the certificate multiplies by the final model's own $H$. The square scaling $d=s^2$ is the base-field isomorphism $x\mapsto s^2x$, $y\mapsto s^3y$, whose differential scale is $1/s$; the certificate never replaces a model by an isomorphic one and keeps scale $+1$ on each edge.

## The trace of an accepted curve and complete preparation

The earlier notes charged $T_{\rm Schoof}$ for the trace of every accepted curve. For this family that overstates the cost, because the trace is determined by $p$ up to sign.

**Proposition (trace).** Let $p\equiv1\pmod{24}$ and $(A,B)\in\mathcal F_3(p)$ with parameter $r$. Then the exact trace $\tau$ of $(A,B)$ equals the exact trace of the seed $(0,-r^3)$, and $\tau=\pm t_0$ where $(t_0,f)$ is the unique pair of positive integers with $4p=t_0^2+192f^2$.

The equality of traces is already proved: $H$ is transported unchanged along the three edges, so $\tau\equiv\tau_{\rm seed}\pmod p$, and both lie in the Hasse interval of width $4\sqrt p<p$. For the seed, the map $(x,y)\mapsto(\omega x,y)$ with $\omega$ a primitive cube root of unity in $\mathbb F_p$ is an automorphism, so $\mathbb Z[\omega]\subseteq\operatorname{End}(E_0)$; since $E_0$ is ordinary its endomorphism ring is an order in an imaginary quadratic field containing the maximal order $\mathbb Z[\omega]$, hence equal to it, and the Frobenius $\pi_0\in\mathbb Z[\omega]$ has norm $p$ and trace $\tau$, so $4p=\tau^2+3s^2$ for an integer $s$. The refinement $8\mid s$ comes from the $2$-isogeny volcano of the component containing $j=0$. Because $2$ is inert in $\mathbb Q(\sqrt{-3})$, the surface of that volcano is the single vertex $j=0$ with no horizontal edges, every vertex strictly between the surface and the floor has exactly one edge up and two down, and the edge up is the dual of the edge by which the vertex was reached; a path with no immediate dual step therefore descends one level per edge, so the family lies at level three and the volcano has depth $d\ge3$. Kohel's structure theorem, in the form stated by Sutherland (*Isogeny volcanoes*, Theorem 7(iv)), gives $d=\nu_2\bigl((\tau^2-4p)/D_0\bigr)/2$ with $D_0=-3$, that is $d=\nu_2(s)$, so $8\mid s$ and $4p=\tau^2+192f^2$ with $s=8f$. Theorem 7 as printed excludes components containing $0$ or $1728$, and Sutherland's Remark 8 states that the only modification for the component of $0$ is the three-to-one collapse of the surface vertex's edges, which is exactly the single-$j$ depth-one layer observed here; the theorem is applied with that caveat recorded. Finally, uniqueness: two distinct representations $4p=t^2+3s^2$ with $8\mid s$ would be related by a unit of $\mathbb Z[\omega]$ other than $\pm1$, and if $\pi$ and $\omega\pi$ both had $8\mid s$ then $\tau\equiv s\pmod{16}$ would force $8\mid\tau$ and $16\mid4p$, which is absurd. The independent worker verified the proposition at six primes and the validation suite verifies it, together with the uniqueness of the representation by brute force, at all $46$ eligible primes below $3000$.

The proposition turns trace preparation into two cheap steps. A square root of $-3$ is $2z+1$ for any primitive cube root of unity $z=c^{(p-1)/3}$ with $c$ a cubic nonresidue, and Cornacchia's algorithm applied to $p=x^2+48y^2$ with the square root $4(2z+1)$ of $-48$ returns $t_0=2x$ and $f=y$. The only remaining datum is the sign of $\tau$, which the prototype decides by a Las Vegas test: for a random rational point $P$, exactly one of $[p+1-t_0]P$ and $[p+1+t_0]P$ vanishes unless $P$ lies in the subgroup killed by both candidate orders, in which case the trial is inconclusive and is repeated; if neither vanishes the proposition itself would be contradicted, which the code reports as a proof violation. The consolidated companion note proves a uniform raw-trial success probability of at least 1/5 for this recognized family, using a group-theoretic bound for p≥337 and eight exact point witnesses at p=97 to close the only small-prime exception. The unbounded variant has at most five raw trials in expectation and terminates almost surely; the default cap is 64 and returns an explicit inconclusive status if exhausted. Observed trial counts are supporting evidence, not the proof of this bound. A deterministic alternative would be the classical sextic-character formula for the trace of $y^2=x^3+B$, which was not verified in a primary source in this pass and is not used. Schoof's algorithm remains the unconditional deterministic theoretical fallback; this prototype does not automatically invoke it. The same proposition gives a necessary condition that a caller-supplied trace must satisfy, $4p-\tau^2=192f^2$ with $f\ge1$, which the prototype now enforces; it rejects the impossible values $11$ and $0$ at $p=73$ that the Hasse interval alone admits, and with `verify_sign=True` it also rejects the wrong-sign value $-10$.

## Reconstruction of K on the original cubic and costs

For the retained cubic $f(w)=1+cw+bw^2+aw^3$, $a\ne0$, the fixed normalization $x=aw+b/3$, $y=av$ has $dw/v=dx/y$, short model $A=ac-b^2/3$, $B=a^2-abc/3+2b^3/27$, and $\beta=aK+(b/3)H$, hence $K=(\beta-(b/3)H)/a$. Equivalently the point $P_+=(0,1)$ of $v^2=f(w)$ maps to the rational point $(x_0,y_0)=(b/3,a)$ of $E$, and every normalized cubic with short model $(A,B)$ arises from a rational point with $y_0\ne0$ as $f=1+\bigl(F'(x_0)/y_0\bigr)w+3x_0w^2+y_0w^3$; its rational branch roots are $\mu=(q-x_0)/y_0$ for the two-torsion abscissae $q$. Once the recognizer accepts the short model and the exact trace is in hand, $H$ is its reduction, $\beta$ is the certified multiplier times $H$, and $K$ follows; the retained branch formula $T_f(\mu)=a\mu(\mu H-K)/f'(\mu)$ is then applied unchanged. The $\beta$ used must be that of the cubic's own short model: for the fixture cubic $f=1+4w+37w^3$ at $p=73$ the short model is $(2,55)$, the $d=16$ twist of $(4,16)$, the recognizer returns $r=16\cdot42$ and multiplier $21$, and the trace $10$, whether supplied or obtained from $73=5^2+48\cdot1^2$ and one sign trial, gives $H=10$, $\beta=64$, $K=55$ and $T_f(9)=3$, agreeing with the retained dense expansion.

| Task | Cost and status |
|---|---|
| Direct recognition and parameter extraction | Constant field work: three inversions and a fixed number of multiplications, independent of $p$ |
| Full certificate (forward and reverse chains, endpoint, multiplier) | Constant field work, a further fixed number of multiplications and inversions |
| Trace candidates $\pm t_0$ | Randomized cubic-nonresidue search, expected at most $1.5$ exponentiations, and $O(\log p)$ Euclidean divisions on $O(\log p)$-bit integers |
| Sign of the trace | Each raw uniform-x draw includes any nonsquare rejection; success probability at least $1/5$, at most five raw trials in expectation; per draw at most one Tonelli–Shanks call and two $O(\log p)$ scalar multiplications |
| Complete unbounded preparation by the CM route | Expected $O(\log^2p)$ field operations plus polynomial integer work, including reconstruction; `prepare_cm(max_trials=None)` terminates almost surely under independent uniform draws |
| Default capped preparation | `prepare_cm` uses 64 raw sign trials; may return `trace_sign_inconclusive`, with conservative probability bound $(4/5)^{64}$; no hidden fallback |
| Complete unconditional deterministic preparation | $T_{\rm Schoof}(E,p)+O(1)$ field operations, retained as the fallback reference cost |
| Prototype accepting an external trace | Trusted apart from the Hasse interval and the necessary condition $4p-\tau^2=192f^2$; optional Las Vegas sign verification |
| Normalization of $f$ and reconstruction of $K$ | $O(1)$ field operations |
| Supplied rational branch query after preparation | $O(1)$ field operations, root checked, by the retained formula |
| Bit cost | Each field operation costs $O(M(\log p))$ and each inversion $O(M(\log p)\log\log p)$ bit operations with fast arithmetic, or $O(\log^2p)$ classically; no arithmetic benchmark is claimed |

Historical PARI `ellap` cross-checks are retained; PARI was unavailable for fresh checks in this consolidation. SEA or PARI may be practical trace alternatives, but no production SEA implementation is supplied and they do not replace the unconditional proof. A constant-time cached query is not a complete run, there are at most three rational branches per cubic, and nothing here supplies $B_L$ and $a_L$ for an original weighted sum, a uniform stopping-index result, or a sum-avoiding Witt correction.

## What is proved, what is tested, what is conjectured, what is deferred

The algebraic content requiring human review consists of the cofactor lemma, the three-step derivation of $\alpha$, $\gamma$ and the multiplier, the relative-norm extraction with its completeness argument, the twist absorption, the integer-factorization exclusions, and the trace proposition, whose only external dependency is Kohel's volcano theorem as stated by Sutherland with the Remark 8 caveat. Each identity among these was also executed exactly in $\mathbb Z[e,g]$ or in $\mathbb F_p$, so an error could only lie in the framing of the Cartier step or in the identification of what the quotient formula represents, both of which are inherited from the retained notes and were re-checked here and by the independent worker.

The finite evidence consists of the following, all passing, with counts that overlap and must not be added. At the ten primes $73,97,193,241,313,337,409,433,457,577$ every one of the $1{,}215{,}024$ nonsingular short models was classified, the $12{,}480$ accepted models coincide exactly with the independent parametrized enumeration and with the brute-force set of nondual depth-three endpoints from $A=0$ seeds, and the recovered parameters agree with the construction. For $2{,}640$ family members the exact $(H,\beta)$ were recomputed by integer multinomial expansion, $H$ was matched against Legendre-symbol traces and PARI `ellap`, $H\ne0$ was confirmed and $\beta$ equalled the certified multiplier times $H$; this covers every member at the four smallest primes. Twists were checked in $702$ cases including every $d$ at $p=73$. Fifteen tampered certificates were rejected, including ones that alter only the stored reverse path, model list, seed or depth, since the verifier now compares every stored field with the recomputed certificate; four impossible or wrong-sign supplied traces and six invalid inputs were rejected. The $96$ retained audit certificates behave as predicted: the $32$ depth-three rows from $A=0$ seeds are recognized with the audit's roots and multipliers, the $32$ depth-three rows from $B=0$ seeds are rejected by this family, and the $32$ depth-four rows are rejected. Forty-eight original normalized cubics built from random rational points at five primes gave $K$ equal to the retained $O(p)$ recurrence and $96$ branch queries equal to dense summation. Family members were recognized at random primes of $17$, $21$, $32$, $41$ and $63$ bits; at the two smallest of these the $O(p)$ recurrence independently confirmed $K$, while at the three largest only the certificate, the reverse path and the PARI trace were checked, so the value of $K$ there rests on the proof. The trace proposition and the uniqueness of the representation were verified at all $46$ eligible primes below $3000$, and $27$ complete CM preparations, including primes of $32$, $41$ and $63$ bits, agreed with Legendre or PARI traces and, where available, with the $O(p)$ recurrence for $K$. The retained $p=13$ obstruction $(1,1)$ is outside the eligible class and is unaffected.

Conjectural or deferred material is confined to the $B=0$ seed. The audit's depth-three classes from $j=1728$ seeds at $p=73,89,113,233$ belong to a second chain whose third kernel roots exist when $4+3e$ is a square for $e^2=2$, by the same cofactor lemma applied to $F_1'(s)=4(4+3e)r^2$; this condition is exact. Descending three levels below $j=1728$ puts that chain at conductor $8$ in $\mathbb Z[i]$, discriminant $-256$, which is why its $j$-values at $p=73$ are the roots of `polclass(-256)` (checked by the independent worker) and why this recognizer rejects it: the resultant row above excludes any $j$-collision at eligible primes, and the two chains have different CM fields. The polynomial $H_{-256}$ has dihedral Galois group and cyclic class group, so $\mathbb Q(j)$ is a non-Galois quartic field and the biquadratic character algebra used here is unavailable. The finite observation that the primes $73,89,113,233$ are of the form $x^2+64y^2$ while $97,193,241$ are not is the expected splitting condition for the ring class field of discriminant $-256$ (a classical statement, Cox's Theorem 9.2 with $n=64$ being the natural pointer), but that source was not reopened in this pass and no recognizer was attempted. Classifying all depth-three families, depth four, and generic or supersingular $K$ recovery remain outside this bounded target.

No approach was abandoned as a failure in this pass. One guard is triggered by design: the recognizer's relative-norm denominators can vanish for inputs outside the family, which is simply a rejection, and the proof shows they cannot vanish for a member at an eligible prime.

## Historical independent validation and reconciliation

The second worker, given only the claims and the file paths, re-derived the family in its own ring arithmetic, eliminated $j$ to the same quartic, recomputed all integer invariants, proved the transport identity from Vélu's map, enumerated the family at six primes, recomputed $(H,\beta)$ for $1{,}856$ members by multinomial expansion, and ran about seventy thousand adversarial inputs against the implementation, including composite moduli congruent to $1$ modulo $24$, same-trace non-members, denominator-vanishing inputs, fourteen certificate tamperings and the audit rows. Every number agreed and no wrong acceptance or rejection was produced. Its report also opened Lario's table, Sutherland's lecture and Katz's paper and confirmed the quotations used here, resolved Katz's bibliographic record, and searched for prior statements of the transport rule and of a discriminant $-192$ recognizer with twist recovery without finding either; that search is not a priority claim.

Its criticisms were accepted and acted on as follows. The cost framing has been replaced by the trace proposition and the CM route above, and the supplied-trace API now enforces the necessary condition and offers sign verification. The certificate verifier now compares every stored field. The role of Deuring's theorem and Kohel's structure theorem has been stated explicitly, and the rejection of the $B=0$ chain is now proved by the additional resultant rather than asserted. The description of degenerations at $p=23$ has been corrected. The phrases "two-parameter family", "two independent scripts" and "defined and ordinary precisely when" have been reworded. The stronger statement at $p\equiv13\pmod{24}$ and the relabeling $r\mapsto\omega r$ have been added. Boolean coefficients are rejected and the unreachable degeneration branches raise a distinct `ProofViolation`. The only point not adopted is a deterministic sign formula, because its classical source was not verified; the Las Vegas test with explicit reporting stands in its place.

## Fresh consolidation checks

The current standard-library validation suite passed again over every nonsingular short model at ten eligible primes from 73 through 577, with no false acceptance or rejection. It recomputed 2,640 coefficient pairs, checked 702 twists, rejected 15 tampered parameter certificates, checked 48 normalized cubics and 96 branch queries, and made 27 CM preparation attempts. PARI was unavailable in this environment: historical PARI records are retained, but no fresh PARI confirmation is claimed, and the large-prime K values rest on the proof except where recurrence checks are recorded.

The new `core/validate_consolidation.py` uses its own left-to-right group-law implementation to verify the eight finite proof witnesses, counts successful raw-x values on 40 small-prime representatives, rechecks decisive trace witnesses, forces retry exhaustion and verifies honest status propagation, and rejects the uncovered easy-seed counterexample. It also checks the corrected `not_in_implemented_families` status on all eight retained p=73 B=0-seed depth-three models. Current source hashes, environments and CSVs accompany these checks. The historical originals are retained under the package root `historical_validation/`.

## Reproduction

From `research/depth_three_recognition_20261007/core`, `python validate_depth_three.py` regenerates `validation.json` and the CSV files, and `python cli.py --p 73 --short 4 16`, `python cli.py --p 73 --f 1 4 0 37 --trusted-trace 10 --verify-sign --mu 9` or `python cli.py --p 73 --f 1 4 0 37 --cm --unbounded-sign-test --mu 9` exercise recognition and preparation. From `theory`, `python check_integer_invariants_depth3.py` reproduces every integer in the table above with the standard library, while `derive_family.py` and `verify_transport.py` need sympy and, optionally, cypari2. The independent worker's scripts and report are under `independent/`. The retained `branch_evaluator.py`, `isogeny_closure.py` and `recognize.py` are included unchanged in their original relative layout. Source hashes, environment and raw CSVs are retained; elapsed validation time is not benchmark evidence.

## Verified primary sources

Sutherland, A. V. (2013). *18.782 Introduction to arithmetic geometry, Lecture 25*, Section 25.3. Massachusetts Institute of Technology. https://ocw.mit.edu/courses/18-782-introduction-to-arithmetic-geometry-fall-2013/e011c006f6aeb95083197457da90598d_MIT18_782F13_lec25.pdf . Reopened 7 October 2026: Section 25.3 gives the explicit degree-two quotient $(x,y)\mapsto(x+a+b/x,\,y(1-b/x^2))$ onto $Y^2=X(X^2+AX+B)$ with $A=-2a$, $B=a^2-4b$, and the dual; it says nothing about differentials. The short-model normalization and the second-kind correction used here are derived explicitly above, not quoted.

Sutherland, A. V. (2013). Isogeny volcanoes. In *ANTS X: Proceedings of the Tenth Algorithmic Number Theory Symposium*, Open Book Series 1, 507–530. https://doi.org/10.2140/obs.2013.1.507 ; author text https://arxiv.org/pdf/1208.5370 . Reopened 7 October 2026: Definition 1 (ℓ-volcano), Theorem 7 (Kohel) with items (i)–(v), including (iv) "the depth of $V$ is $d=\nu_\ell((t^2-4q)/D_0)/2$", and Remark 8 on components containing $0$ or $1728$. Used for the trace proposition only.

Katz, N. M. (2021). On a question of Zannier. *Experimental Mathematics*, 30(3), 422–428. https://doi.org/10.1080/10586458.2018.1551818 ; author-hosted text https://web.math.princeton.edu/~nmk/zannier_publ.pdf . Reopened 7 October 2026: Section 1 identifies $C(dx/y)$ and $C(x\,dx/y)$ with the coefficients of $x^{p-1}$ and $x^{p-2}$ in $f^{(p-1)/2}$; Theorem 3.1 states that the two coefficients have no common zero. Bibliographic record confirmed at https://collaborate.princeton.edu/en/publications/on-a-question-of-zannier/ .

Lario, J.-C. (n.d.). *Elliptic curves with CM defined over extensions of type (2,…,2)*. Author-maintained computational table. https://web.mat.upc.edu/joan.carles.lario/ellipticm.htm . Reopened 7 October 2026: the entry `{-192,{2,3},x^4-8041801037378436000*x^3+…}` agrees with the polynomial derived above and records $\mathbb Q(j)=\mathbb Q(\sqrt2,\sqrt3)$; the entries for $-48$ and $-64$ agree with the retained $P_3$ and $P_2$. A research data page, not a refereed proof; discriminant $-256$ is not in it.

The PARI/GP system, through cypari2, was used for `polclass`, `quadclassunit`, `polgalois`, `factor` and `ellap` as independent computational cross-checks only; $H_{-256}$ is taken from `polclass(-256)` and used solely in the collision resultant. Schoof, R. (1995), *Counting points on elliptic curves over finite fields*, Journal de Théorie des Nombres de Bordeaux 7(1), 219–254, https://www.numdam.org/item/JTNB_1995__7_1_219_0/ , remains the retained reference for the deterministic fallback and was not reopened in this pass; Cox's *Primes of the form $x^2+ny^2$* is cited as a pointer only and was not opened. No broad priority review has been performed and no novelty is claimed for the family, which is the classical conductor-eight CM family; the explicit normalized coefficient transport, the relative-norm recognizer, the trace proposition and the collision exclusions are supplied as elementary derivations for review.

The current retry-bound proof additionally verifies Sutherland (2025a), Lecture 6, Corollary 6.4, and Sutherland (2025b), Lecture 23, Corollary 23.24; exact source URLs and their roles are in TRACE_SIGN_BOUND_20261007.md. The new trial bound is our derivation, not a theorem quoted from those sources.


# Consolidated trace-sign bound for the depth-three family

7 October 2026. This is an unrefereed consolidation of the discriminant −192 extension, not a revision of the published Cartier–Miller manuscript. The family and recognition theorem are in the companion proof note. The new result below closes the trace-sign trial-count gap, conditional on that note's recognized-family trace proposition. No novelty or measured performance claim is made.

## Hypotheses and exact sign certificates

Let p be prime with p congruent to 1 modulo 24, and let E: y²=x³+Ax+B belong to the parameter-verified depth-three family from the ordinary j=0 seed. The retained trace proposition gives a unique pair of positive integers (t₀,f) with 4p=t₀²+192f² and the exact trace τ in {t₀,−t₀}. Set n₊=p+1−t₀, n₋=p+1+t₀ and g=gcd(n₊,n₋). All conclusions below use this two-candidate theorem. They are not certificates of arbitrary curve orders.

For a rational point P, if exactly one of [n₊]P and [n₋]P is the identity, that candidate is the true group order: the true order annihilates every rational point by Lagrange's theorem, and the other candidate demonstrably fails on P. This is an exact point witness, not a probabilistic inference from an annihilation test alone. The implementation now retains P, the candidate orders and their annihilation flags, and `verify_trace_sign_witness` rechecks the point equation and both scalar multiplications. If both vanish the trial is inconclusive. If neither vanishes the recognized-family trace premise or the implementation is wrong; this is reported as a proof violation.

Write G=E(F_p), N=#G=p+1−τ. The inconclusive subgroup is exactly K=G[g]. Indeed points killed by both n₊ and n₋ are killed by their gcd, by Bézout's identity, and the converse is immediate. Since the true N is one candidate, this is also the kernel of the other candidate acting on G.

## A proper subgroup at all large eligible primes

The standard finite-field group structure is G≅Z/n₁Z⊕Z/n₂Z, n₁|n₂, n₁n₂=N, with n₁|p−1. For completeness, the rank-two statement and p∤n₁ follow from torsion structure (Sutherland, 2025a, Corollary 6.4). All n₁² geometric n₁-torsion points are then rational, so the Weil pairing puts the n₁-th roots of unity in F_p and implies n₁|p−1 (Sutherland, 2025b, Corollary 23.24). Therefore

$$|K|=\gcd(n_1,g)\gcd(n_2,g).$$

Because g divides both N and 2τ, gcd(n₁,g) divides gcd(p−1,N,2τ). Any divisor of the latter divides N−(p−1)=2−τ and 2τ, and consequently divides 4. Hence

$$|K|\le4g\le8|\tau|\le16\sqrt p.$$

For p≥337, Hasse's bound gives N≥p+1−2√p>16√p; the last inequality follows from (p+1)²>324p. Thus K is a proper subgroup. This argument is uniform in p and uses no enumeration of family members or observed trial counts.

## The finite small-prime exception

The eligible primes below 337 are exactly 73, 97, 193, 241 and 313; trial division verifies this finite list. Their unique representations give the following exact integer data.

| p | t₀ | f | g | min(n₊,n₋) | Bound 4g |
|---|---|---|---|---|---|
| 73 | 10 | 1 | 4 | 64 | 16 |
| 97 | 14 | 1 | 28 | 84 | 112 |
| 193 | 2 | 2 | 4 | 192 | 16 |
| 241 | 14 | 2 | 4 | 228 | 16 |
| 313 | 22 | 2 | 4 | 292 | 16 |

The bound already proves K proper for four rows. Only p=97 requires point witnesses. Here √3∈{10,87}, √2∈{14,83}, and 5 is a quadratic nonresidue, since 5⁴⁸≡−1 modulo 97. Every nonzero r is either s² or 5s² for some s∈F_97*. The parameter model at r=r₀s² is isomorphic over F_97 to the model at r₀ by x↦s²x, y↦s³y. Thus the four embeddings and r₀∈{1,5} give eight representatives of all family models. The following exact witnesses are on those curves and are not killed by g=28.

| e | √2 | r₀ | (A,B) | P | [28]P |
|---|---|---|---|---|---|
| 10 | 14 | 1 | (89,26) | (2,55) | (12,94) |
| 10 | 14 | 5 | (91,49) | (0,90) | (80,66) |
| 10 | 83 | 1 | (16,30) | (3,69) | (43,54) |
| 10 | 83 | 5 | (12,64) | (0,89) | (35,0) |
| 87 | 14 | 1 | (61,77) | (3,53) | (43,57) |
| 87 | 14 | 5 | (70,22) | (1,53) | (0,64) |
| 87 | 83 | 1 | (13,24) | (0,86) | (12,68) |
| 87 | 83 | 5 | (34,90) | (3,92) | (73,0) |

These are finite algebraic certificates, not an extrapolation from numerical agreement. Each curve equation and displayed scalar multiplication is checked by an independent left-to-right group-law implementation in `core/validate_consolidation.py`. Isomorphisms preserve the property [28]P≠O, so this proves K proper for every family member at the single exceptional prime. The CSV `core/sign_bound_p97_witnesses.csv` retains the certificates in machine-readable form.

## Bound for the actual random-x sampler

At every eligible prime, K is proper, hence |K|≤N/2. The code samples x uniformly in F_p, computes a square root of x³+Ax+B if it exists, and rejects y=0. This does not sample uniformly from all points of G, so a point-based probability cannot be substituted without checking the sampler.

Since t₀ is even, both candidate orders are even. Thus O and all rational two-torsion points lie in K. Every point outside K has y≠0, and P and −P are either both outside or both inside K. The N−|K| successful affine points consequently correspond to exactly (N−|K|)/2 distinct x values; either square-root choice succeeds. One raw x draw has success probability

$$\frac{N-|K|}{2p}\ge\frac{N}{4p}\ge\frac15.$$

For p≥97, the last inequality follows from p+1−2√p≥4p/5. At the remaining eligible prime p=73 the exact candidates give N≥64>4p/5. All non-square and zero-right-hand-side draws are already charged in this bound.

With independent uniform draws, the unbounded algorithm has expected raw trial count at most 5 and terminates almost surely; the probability of still being inconclusive after k raw draws is at most (4/5)^k. The default cap is now 64, whose conservative inconclusive bound is about 6.28×10⁻⁷. This is a bound on returning no answer, not a probability of a wrong answer. `max_trials=None` and CLI `--unbounded-sign-test` expose the unbounded zero-error version. The capped version retains the explicit inconclusive status and does not guess or invoke an unseen fallback. Arbitrary user-supplied deterministic RNGs need not satisfy the uniformity assumption.

## Preparation and query costs

Put n=⌈log₂p⌉. Recognition after prime validation uses a constant number of field operations; this counts inversions as field operations and is not constant bit time. Cornacchia uses O(n) Euclidean divisions on O(n)-bit integers. A random cubic-nonresidue search has expected at most 3/2 exponentiation attempts. Tonelli–Shanks has O(n²) field operations per square-root attempt, including its loop, and its random nonresidue selection has expected at most two attempts. Each sign trial makes at most two O(n)-length scalar multiplications. The raw sign trial bound therefore yields expected O(n²) field operations plus polynomial integer work for complete unbounded preparation. Using elementary O(n²) multiplication and inversion, O(n⁴) bit operations is a conservative combined upper bound, not a sharp complexity claim.

| Operation | Charge and limitation |
|---|---|
| Prime validation in the prototype | Separately charged; deterministic validation only for 7≤p<2⁶⁴; the mathematical statement assumes a prime supplied or certified independently |
| Recognition, path checking and K reconstruction after the trace | O(1) field operations, including inversions |
| Complete unbounded CM preparation | Expected O(log²p) field operations and polynomial bit work; almost-sure termination under independent uniform draws |
| Default capped CM preparation | Same per-trial cost, at most 64 raw sign draws; may return an honest inconclusive status; internal nonresidue searches remain randomized |
| Supplied nonzero rational branch query after preparation | O(1) field operations, including root validation and output reconstruction; root finding is outside the query |
| Complete unconditional deterministic alternative | Schoof trace preparation plus O(1) field operations; the prototype does not automatically invoke this backend |

The expected bound is a theoretical derivation, not a timing result. It computes H, K and a supplied branch/root value. It does not claim an original weighted-sum evaluator for arbitrary stopping indices; such a claim still requires both B_L and a_L. It says nothing new about a sum-avoiding Witt correction.

## Preserved obstruction and mathematical scope

On the easy seed E:y²=x³+19 over F_97, exact enumeration gives #E=112 and τ=−14. Every rational point is killed by 28, so both candidate orders 84 and 112 annihilate every point. A sign algorithm on this seed could remain inconclusive forever. The independent enumeration and scalar-multiplication checks are retained in `core/sign_test_obstruction.json` and its generating validator. This obstructs applying the success theorem to arbitrary curves or to every easy seed, even when there are exactly two correct trace candidates. The implementation now checks the depth-three recognition premise before attaching the bound.

The retained differential normalization is unchanged. With t=−x/y at infinity, x=t⁻²+O(t²), y=−t⁻³+O(t), ω=2dt+O(t⁴)dt and η=2t⁻²dt+O(t²)dt. For the quotient rooted at q, u=F′(q), the primitive y/(x−q) has leading term −t⁻¹ at infinity. Thus −2d(y/(x−q)) contributes −2t⁻²dt, reducing the leading term of (2x−q)ω from +4t⁻²dt to +2t⁻²dt. At the kernel use z=y: x−q=z²/u+O(z⁴), ω=(2/u+O(z²))dz and the primitive is u/z+O(z), so the same exact correction has principal part +2u z⁻²dz. The quotient term x′ω has that same positive principal part there. Both poles have residue zero, and the differential scale remains +1. Cartier kills the global exact differential, yielding β′=2β−qH with the stated sign. These are local checks accompanying the retained global rational-function identity, not replacements for it.

The family-recognition proof, the CM trace proposition and this success-bound proof remain unrefereed. Their correctness and any priority claims need human review. The counterexample, finite certificates, retained historical validation and fresh checks have separate roles and must remain distinct.

## Primary sources checked for the new argument

Sutherland, A. V. (2025a). *18.783 Elliptic curves, Lecture 6: Torsion subgroups and endomorphism rings*. Massachusetts Institute of Technology. Corollary 6.4, pp. 1–2. https://math.mit.edu/classes/18.783/2025/LectureNotes6.pdf . Opened 7 October 2026; used for rank-two group structure and p∤n₁, not for the new probability bound.

Sutherland, A. V. (2025b). *18.783 Elliptic curves, Lecture 23*. Massachusetts Institute of Technology. Theorem 23.23 and Corollary 23.24, pp. 9–13. https://math.mit.edu/classes/18.783/2025/LectureNotes23.pdf . Opened 7 October 2026; used for the Weil-pairing implication E[n₁]⊆E(F_p)⇒n₁|p−1. These are authoritative course notes, not new research claims.

The prior note's CM trace argument uses Sutherland (2013), *Isogeny volcanoes*, Theorem 7(iv) and Remark 8, which were reopened in the preceding review. Hasse's bound, the recognized-family CM reduction, and all normalization assumptions are stated explicitly in the companion proof note. No deterministic sextic-character sign formula is asserted here.
