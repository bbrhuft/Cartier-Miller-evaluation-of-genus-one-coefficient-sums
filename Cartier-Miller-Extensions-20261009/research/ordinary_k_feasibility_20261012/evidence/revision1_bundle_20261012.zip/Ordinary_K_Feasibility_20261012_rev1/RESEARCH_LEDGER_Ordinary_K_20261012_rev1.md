# Research ledger: ordinary slope from canonical lifting (revision 1, 12 October 2026)

Updated after the independent review. The note `Ordinary_K_Feasibility_Note_20261012_rev1.md` holds the proofs; `CHANGES.md` records each review finding. Negative results keep their exact scope.

| Field | Record |
|---|---|
| Question | Can E/F_p and its certified trace yield κ = β/H through canonical-lift data, without an equivalent expensive coefficient? |
| Assumptions | p ≥ 7 prime and growing; nonsingular ordinary short model; certified signed trace; basis ω = dx/y, η = x dx/y with low-pole primitives |
| Outcome | Conditional/oracle reduction, plus obstructions specific to the constructions examined. Those constructions did not yield a cheaper complete algorithm; whether canonical-lift or Serre–Tate data could give a shortcut is unresolved. No lower bound, hardness, speed-up or novelty is claimed |
| Theorem A (derived) | M̄ = [[0, −β],[0, H]] (column convention, low-pole basis); b₀ = −β, d₀ = H; precision p; also for supersingular models. Confirmed independently by Čech cocycles on all 1,428 nonsingular models with 7 ≤ p ≤ 23 plus samples, and by a Kedlaya-type computation |
| Lemma B (derived, modulo listed classical inputs) | For any ordinary short lift Ẽ/Z_p with connected subgroup C: σ_C ∈ pZ_p and κ ≡ σ_C/p; the quotient identification reduces to γ∘F with γ ∈ Aut(E), and γ (in particular the sign) cancels. Needed precision: G₀ mod p², G₁ mod p³; executed floor N = 3 works and N = 2 is refused (270/270 each) |
| Classical inputs to Lemma B | Verified in accessible notes: isogeny invariance of good reduction; smooth Weierstrass model = Néron model; extension of morphisms. Not re-read: formal-group height and preparation, factorization through F, finite flatness, de Rham base change, connected–étale sequence. The crystalline remark (Berthelot–Ogus) is not used |
| Propositions C, D, E (derived) | c = σ_C/(λ̄² − p) at the canonical lift; β = −Σ_{E(F_p)}x and κ = −σ_V/t²; β = ϑH, ϑ = 6B∂_A − (4/3)A²∂_B. D is one explicit method, not shown necessary |
| Information versus difficulty | σ_C mod p², σ_V, ϑH at a point and b₀ are each equivalent to κ given t. This is information only and implies nothing about computational difficulty |
| j_can modulo p² | For AB ≠ 0 it fixes E_can mod p² up to isomorphism; no recovery map from it to κ was identified, and none is excluded. Separately, at j = 0 and 1728 coarse j mod p² does not distinguish non-isomorphic lifts (derived; 69 lifts executed) |
| Serre–Tate data | Four representations distinguished (full point, Kummer coordinate, kernel polynomial, intrinsic deformation description), with encoding sizes and named-construction costs; no cheaper construction found; unresolved |
| Maiga–Robert | Theorems 1.1–1.2 assume j ∉ F_{p²}, which excludes our inputs from those theorems. Canonical lifting itself is not excluded; canonical lifts of F_p-curves were computed here by Deligne–Tate iteration |
| Withdrawn statements | Θ(p) size of universal J₁ (unverified); "typical" k = ord(t mod p) and "generic \|D\| ≍ p" (heuristic); "route closed"; "lift independence shows canonical data are not the relevant datum" |
| Comparators | BGS Theorem 14 on the order-3 recurrence (Õ(√p), theorem, not implemented); Harvey (2008) Theorem 1 (Õ(p^{1/2}N^{5/2}) for p > 6N). No generic native BGS backend is retained |
| Retained dependency | fixed_D_evaluator.py (69ec09…) and cm_tables.json (66bbf3…) match the extension manifest; the completed depth_three_b0_recognize.py (a7142c…) and depth_three_recognize.py (b3bffe…) match the inherited manifest and are the modules actually imported; executed cross-check at p = 73, 89, 97, 113 agrees everywhere |
| Validation families | A original pilot; B original independent pass (exit-status defect reproduced); C review reruns (not available); D repaired runs (pilot, retained check, precision floor, independent full profile, failure injections) |
| Preserved failures | π−1 check over-strong at p = 7 (w_G ≡ 2); lift-dependence of higher digits of σ_C/p (515/570); original runners exiting 0 on mismatch; the 1,418 miscount; historical precision-two counterexamples untouched |
| Open | A sub-square-root construction of any scalar equivalent to κ (σ_C mod p², σ_V, ϑH, b₀), or a proof that canonical-lift or Serre–Tate data cannot supply one |

## Dependency table

| Route/object | Assumptions | Exact construction | Size | Cold cost | Cached cost | Reconstruction | Bound type | Status |
|---|---|---|---|---|---|---|---|---|
| Canonical j modulo p² | AB ≠ 0, ordinary | Universal J₁; CM root of H_D; or one Deligne–Tate step | J₁ size not established; h(D) coefficients for CM; DT as below | Not established (J₁); Õ(\|D\|) under GRH plus order discovery (CM, cited); DT as below | — | No identified map to κ | Heuristic / Theorem (cited) / Construction | Examined constructions gave no cheaper κ; existence of a useful map not excluded |
| Minimal Frobenius fragment | Low-pole basis | Entry (1,2) of M mod p | 1 element | Supplier's | O(1) | κ = −b₀/H | Oracle | Oracle reduction; fragment is β |
| Canonical-subgroup kernel sum | Any lift, ordinary | Canonical factor (ψ_p route or [p]-series route) | Needed: G₀ mod p², G₁ mod p³ (O(log p) bits) | Θ(p²) (ψ_p route) or about 2p series terms ([p]-series route) | Same | κ = σ_C/p | Size / Construction | Proved identity; no cheaper construction found |
| Serre–Tate chart and étale data | Ordinary | Four representations (note §6) | Exact encoding sizes per representation | Per named construction | — | κ = −σ_V/t² from the kernel sum | Size / Construction / Heuristic | No cheaper construction found; necessity not shown |
| Derivative of the Hasse invariant | — | ϑH at (A,B) | Θ(p) monomials of H | Θ(p) | Θ(p) | κ = ϑH/H | Size / Construction | Equivalent to β |
