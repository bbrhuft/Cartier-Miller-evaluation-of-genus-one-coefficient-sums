# Research ledger: ordinary slope from canonical lifting (updated 12 October 2026)

Opened from the handover ledger of the same date and filled in after the bounded feasibility study. Negative results keep their exact scope. The feasibility note `Ordinary_K_Feasibility_Note_20261012.md` holds the proofs; this ledger records status.

| Field | Record |
|---|---|
| Question | Can E/F_p and its certified trace yield κ = β/H through canonical-lift data, without an equivalent expensive coefficient? |
| Assumptions | p ≥ 7 prime and growing; nonsingular ordinary short model; signed trace certified; basis ω = dx/y, η = x dx/y in the low-pole convention |
| Outcome | Conditional/oracle reduction plus route-specific obstructions. No cheaper algorithm; no new restricted class certified; generic question unresolved; no lower bound claimed |
| Normalization checkpoint | Proved and sharpened: M̄ = [[0, −β],[0, H]] in the column convention, so b₀ = −β, d₀ = H, κ = −b₀/d₀, precision p, lift-independent (Theorem A). Holds for supersingular models too (then image = ⟨ω⟩) |
| Convention caveat | Only for the low-pole primitive (pole order < p); adding s(x²/y)^p to the primitive shifts [η] by (s/2)F\*[η] and changes the (1,2) entry. Row convention gives the transpose |
| Smallest Frobenius fragment | The (1,2) entry modulo p, which is −β itself; supplying it is a β-oracle |
| New recovery maps (proved) | κ ≡ σ_C/p for the canonical subgroup of any lift (Prop. B); c = σ_C/(λ̄² − p) at the canonical lift (Prop. C); β = −Σ_{E(F_p)} x and κ = −σ_V/t² (Prop. D); β = ϑH, ϑ = 6B∂_A − (4/3)A²∂_B, so κ = ϑ log H (Prop. E) |
| j_can modulo p² | For AB ≠ 0 it fixes E_can mod p² up to an isomorphism ≡ id mod p, but κ is lift-independent and every identified map also needs the canonical-subgroup kernel sum. For AB = 0 it is not a fine invariant: j ≡ 0 mod p³ (resp. j ≡ 1728 mod p²) for every lift; observed on 69 lifts. Route closed |
| Serre–Tate description | q = 1 only locates E_can, which Prop. B makes unnecessary; markings need étale p-torsion over F_{p^k}, k = ord(t mod p); conversion to (ω,η) is σ_V, i.e. κ again. Route closed |
| Maiga–Robert | Theorems assume j ∉ F_{p²}; every E/F_p is excluded (inference from F_p ⊂ F_{p²}); Newton on Φ_p(X,X) degenerates since Φ_p(X,X) ≡ −(X^p − X)² |
| Justified comparators | BGS Theorem 14 on the order-3 recurrence for [x^n]F^h (Õ(√p), theoretical here); Harvey (2008) Theorem 1, E₂ mod p^N in Õ(p^{1/2}N^{5/2}) for p > 6N. No generic native BGS backend exists in the retained material |
| Independent controls | Char p: 1,574 ordinary models (π−1 point sum and Vélu codomain), 1,395 (Verschiebung kernel), 1,256 twists, 193 supersingular. p-adic: 570 ordinary models × trivial and random lifts, 240 canonical lifts, 29 CM-over-Q pairs, 74 retained fixed-D curves, 507 original cubics with full (H,K,T). Serre-derivative identity on 19,948 models. All PASS; failure injection detected in all three scripts |
| Independent verification pass | Separate agent without access to the code: Theorem A by Čech cocycles and by Kedlaya–Monsky–Washnitzer; Prop. B via the formal group (1,026 model–lift pairs); Prop. D with explicit étale points (1,256 models); Prop. E proved by an exact identity ϑH = (p+1)β − (4p/3)A[x^p]F^h |
| Retained dependency | Fixed-D evaluator imported from the completed extension source (path and SHA-256 in `padic_summary.json`); completed depth-three recognizers hashed, not executed, so the 2,256-mismatch old comparator cannot arise |
| Preserved corrections | My first π−1 check wrongly required w_G ≡ 0; at p = 7, (A,B) = (0,1), w_G ≡ 2 while B − 7w_G ≡ B. Only κ mod p is lift-invariant: σ_C/p mod p² differs between trivial and random lifts in 515 of 570 models |
| Preserved historical failures | Untouched: p = 13 sum lifts (44, 83 vs 70 mod 169); pole obstruction to the archived bounded-degree CM defect; rounded-third supersingular factorial equivalence. None is generalized |
| Open | A sub-square-root formula for any of σ_C mod p², σ_V, ϑH at a point, or b₀ would be a new algorithm for κ; none is known, none is excluded |

## Dependency table

| Route/object | Assumptions | Exact construction | Size | Cold cost | Cached cost | Reconstruction/basis cost | Independent check | Status |
|---|---|---|---|---|---|---|---|---|
| Canonical j modulo p² | AB ≠ 0, ordinary | Erdoğan–Finotti J₁ (Θ(p) coefficients), CM root of H_D, or one Deligne–Tate step | Θ(p), or h(D) ≍ √\|D\| with \|D\| ≍ p generically | ≥ Θ(p) in every identified construction | Θ(p) per J₁ evaluation | No identified map to κ | DT recovers j_CM mod p² from random lifts; H_D(j_can) ≡ 0 mod p³ on 74 curves; AB = 0 failure on 69 lifts | Route-specific obstruction (no recovery map; data size; Newton hypothesis failure) |
| Minimal Frobenius fragment | Low-pole basis | Entry (1,2) of M mod p | 1 element | Charged to supplier; equals −β | O(1) | κ = −b₀/H | Three methods (π−1, Čech, Kedlaya) | Oracle reduction; fragment is β |
| Canonical-subgroup kernel sum | Any lift, ordinary | Slope-1/(p−1) factor of [p]-series or reversed ψ_p, precision ≥ p³ | Θ(p)–Θ(p²) inputs | Θ(p)–Θ(p²) | Same | κ = σ_C/p | 570 + 1,026 model–lift pairs | Oracle proved; data-size obstruction; equivalent to κ |
| Serre–Tate chart/markings | Ordinary | Étale point over F_{p^k}, k = ord(t mod p); μ_p side over Z_p[ζ_p] | Θ(k log p) bits per point; Θ(kp) for the kernel | Õ(k² log p) per point; Θ(kp) for σ_V | — | κ = −σ_V/t² | 1,395 (ψ_p) + 1,256 (explicit points) | Route-specific obstruction; t = ±1 gives cheap points but Θ(p) summands (√p-parity at best, unimplemented inference) |
| Derivative of the Hasse invariant | — | ϑH at (A,B) | Θ(p) monomials | Θ(p) | Θ(p) | κ = ϑH/H | 19,948 models; exact identity p ≤ 71 | Equivalent to β; no derivative oracle from point counting |
