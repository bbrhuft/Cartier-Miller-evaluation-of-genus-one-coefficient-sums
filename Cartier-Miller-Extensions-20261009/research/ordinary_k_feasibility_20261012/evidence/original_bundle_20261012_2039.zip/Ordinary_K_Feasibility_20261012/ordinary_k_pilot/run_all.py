"""Run every check with failure propagation; write a manifest of hashes.

Usage (from any directory):
    RETAINED_RESEARCH=<completed research tree> \
    CM_EXTENSION_SOURCE=<.../source/CM_Cartier_Extension_20261012> \
    HANDOVER_ROOT=<.../Ordinary_K_Research_Handover_20261012> \
    python -I run_all.py

Each child must print its PASS sentinel AND exit 0; otherwise this runner
exits 1.  Mathematical counters are in results/*.json.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
STEPS = [('charp_identities.py', 'CHARP_IDENTITIES_PASS'),
         ('serre_derivative_check.py', 'SERRE_DERIVATIVE_PASS'),
         ('padic_canonical_subgroup.py', 'PADIC_PILOT_PASS')]


def main():
    log = []
    ok = True
    for script, sentinel in STEPS:
        t0 = time.time()
        proc = subprocess.run([sys.executable, '-I', str(HERE / script)], capture_output=True, text=True)
        passed = proc.returncode == 0 and sentinel in proc.stdout
        ok &= passed
        log.append({'script': script, 'returncode': proc.returncode, 'sentinel_seen': sentinel in proc.stdout,
                    'seconds': round(time.time() - t0, 2), 'stdout_tail': proc.stdout[-1500:],
                    'stderr_tail': proc.stderr[-1500:]})
        print(f'{script}: {"PASS" if passed else "FAIL"} (rc={proc.returncode})')
    files = sorted(p for p in HERE.rglob('*') if p.is_file() and p.suffix in ('.py', '.csv', '.json')
                   and p.name != 'MANIFEST.json')
    manifest = {'overall': 'PASS' if ok else 'FAIL', 'steps': log,
                'sha256': {str(p.relative_to(HERE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    (HERE / 'results' / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2))
    if not ok:
        sys.exit(1)
    print('ALL_PASS')


if __name__ == '__main__':
    main()
