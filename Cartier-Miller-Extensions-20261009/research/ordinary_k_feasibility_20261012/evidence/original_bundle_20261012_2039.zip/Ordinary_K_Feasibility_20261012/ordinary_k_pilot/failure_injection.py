"""Failure injection: confirm that wrong mathematics produces a nonzero exit.

Copies the pilot into a temporary directory, applies one deliberate error per
trial, runs the patched script, and requires a nonzero return code plus a
FAIL line.  Also checks that run_all.py propagates a child failure.
"""
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
TRIALS = [
    ('padic_canonical_subgroup.py', "'kappa_C': (sigma / p).residue(1)", "'kappa_C': ((sigma / p).residue(1) + 1) % p"),
    ('charp_identities.py', 'kV = (-sV * pow(t * t, -1, p)) % p', 'kV = (sV * pow(t * t, -1, p)) % p'),
    ('serre_derivative_check.py', '(6 * B * HA - 4 * i3 * A * A * HB) % p == beta', '(6 * B * HA + 4 * i3 * A * A * HB) % p == beta'),
]


def main():
    results = []
    for script, old, new in TRIALS:
        with tempfile.TemporaryDirectory() as td:
            dst = Path(td) / 'pilot'
            shutil.copytree(HERE, dst, ignore=shutil.ignore_patterns('results', '__pycache__'))
            src = (dst / script).read_text()
            if old not in src:
                print('injection anchor not found:', script)
                sys.exit(1)
            (dst / script).write_text(src.replace(old, new, 1))
            proc = subprocess.run([sys.executable, '-I', str(dst / script)], capture_output=True, text=True)
            caught = proc.returncode != 0 and 'FAIL' in proc.stdout
            runner = subprocess.run([sys.executable, '-I', str(dst / 'run_all.py')], capture_output=True, text=True)
            results.append((script, proc.returncode, caught, runner.returncode))
            print(f'{script}: injected error -> rc={proc.returncode}, caught={caught}; runner rc={runner.returncode}')
    if not all(c and r != 0 for _, _, c, r in results):
        print('FAILURE_INJECTION_NOT_DETECTED')
        sys.exit(1)
    print('FAILURE_INJECTION_DETECTED_ALL')


if __name__ == '__main__':
    main()
