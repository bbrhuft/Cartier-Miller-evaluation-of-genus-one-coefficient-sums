# Ordinary Cartier slope from canonical-lift data: feasibility bundle (12 October 2026)

Start with `Ordinary_K_Feasibility_Note_20261012.md`. It contains the proofs, the information audit, the dependency and cost table (§5), the source audit (§7), the observed validation (§8), the status separation (§9) and the plain-language conclusion (§10). `RESEARCH_LEDGER_Ordinary_K_20261012.md` is the updated ledger in the handover's format.

The outcome is a conditional/oracle reduction together with route-specific obstructions. The handover's checkpoint holds exactly: crystalline Frobenius modulo p in the low-pole basis is [[0, −β],[0, H]]. So the smallest Frobenius fragment that determines κ is β itself. On the lift side, κ ≡ σ_C/p for the canonical subgroup of any lift (the canonical lift itself is not needed), κ = −σ_V/t² for the étale p-torsion, and κ = ϑ log H for the Serre derivative ϑ = 6B∂_A − (4/3)A²∂_B. Every identified construction of these scalars is at least linear in p, or square-root scale through a BGS-type device. The precision-p² and Serre–Tate routes are closed for explicit reasons. No cheaper algorithm, no new restricted class and no lower bound are claimed.

| Path | Contents |
|---|---|
| `ordinary_k_pilot/` | Standard-library verification code (`okp_common.py`, `charp_identities.py`, `serre_derivative_check.py`, `padic_canonical_subgroup.py`, `coverage.py`, `failure_injection.py`, `run_all.py`) and raw outputs in `results/` (CSV, JSON, logs, `MANIFEST.json`) |
| `independent_check/` | Code and raw outputs of a separate verification pass written without access to the pilot or the note: Čech and Kedlaya–Monsky–Washnitzer checks of Theorem A, formal-group check of Proposition B, explicit étale-point check of Proposition D, exact proof check of Proposition E, Katz sign check |
| `handover_verification.md` | What was run from the received handover and what it returned |
| `SHA256SUMS.json` | Hashes of every file in this bundle |

To reproduce, extract the received handover, run its `unpack_support.py`, and set three variables before running the pilot:

```bash
export RETAINED_RESEARCH=<printed RETAINED_RESEARCH directory>
export CM_EXTENSION_SOURCE=<support>/CM_Cartier_Adversarial_Review_20261012/source/CM_Cartier_Extension_20261012
export HANDOVER_ROOT=<path to Ordinary_K_Research_Handover_20261012>
python -I ordinary_k_pilot/run_all.py          # prints ALL_PASS, exit 0
python -I ordinary_k_pilot/coverage.py
python -I ordinary_k_pilot/failure_injection.py  # prints FAILURE_INJECTION_DETECTED_ALL
```

Without `CM_EXTENSION_SOURCE`, the retained fixed-D positive controls are skipped and the counter `retained_fixedD_agreements` is zero; every other check still runs. Each script exits nonzero on any mathematical disagreement, and the runner propagates that. The observed run took about 30 seconds under Python 3.13.16; this is reproducibility information, not a benchmark. The manuscript, the retained research and the historical precision-two branch were not modified. Nothing was published, and no repository was inspected or changed.
