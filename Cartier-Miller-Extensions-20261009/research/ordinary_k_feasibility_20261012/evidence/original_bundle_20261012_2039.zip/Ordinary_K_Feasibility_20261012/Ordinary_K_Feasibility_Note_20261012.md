# Ordinary Cartier slope from canonical-lift data: normalization, recovery maps and route obstructions

**Feasibility note, 12 October 2026.** For David Jordan's Cartier–Miller extension programme.

This is an AI-assisted research note. It has not been refereed. It does not revise the published manuscript, it publishes nothing, and no repository was inspected or changed. Every numerical statement is observed output from the scripts in `ordinary_k_pilot/`, run in the environment recorded in §8. Section 9 separates classical facts, statements proved here, tested prototypes, conjectures and corrected or failed approaches.

## 0. Outcome

The outcome is **a conditional/oracle reduction together with route-specific obstructions**. No complete cheaper algorithm was found, and no new restricted class is certified. The generic question (is there a sub-square-root algorithm for κ = β/H given E and t?) remains unresolved; nothing here is a lower bound.

The handover's normalization checkpoint is **correct**, and it can be made exact. With the column convention φ\*(ω,η) = (ω,η)M and the low-pole basis, the reduction of crystalline Frobenius is

$$\overline M=\begin{pmatrix}0&-\beta\\0&H\end{pmatrix}\qquad(\text{Theorem A}).$$

So b₀ = −β on the nose, d₀ = H, κ = −b₀/d₀, and only precision p is needed. The "smallest fragment of lift data sufficient to determine b₀" is therefore β itself: any oracle for that entry is a β-oracle, and extracting κ from it is an O(1) oracle reduction that does not touch the cost of β.

On the lift side the useful exact statements are four recovery maps, all proved below and all validated numerically. For **any** integral lift Ẽ of E (the canonical lift is not needed), the canonical subgroup C ⊂ Ẽ[p] has kernel sum σ_C ≡ 0 (mod p) and κ ≡ σ_C/p (mod p) (Proposition B). At the canonical lift the same sum gives the p-adic unit-root coordinate exactly (Proposition C). In characteristic p, β = −Σ_{P∈E(F_p)} x(P) and κ = −σ_V/t², where σ_V sums x over the étale p-torsion (Proposition D). Finally β = ϑH with ϑ = 6B∂_A − (4/3)A²∂_B, so κ = ϑ log H is a logarithmic Serre derivative of the Hasse invariant (Proposition E).

Each recovery map needs one scalar that is equivalent to κ given t (σ_C/p, σ_V, a transverse derivative of H, or b₀), and every construction of that scalar identified in the literature or here uses data of size at least linear in p, or reaches the square-root scale only through a baby-step/giant-step device of the same kind as Bostan–Gaudry–Schost (BGS). The two named routes stop for explicit reasons: j_can modulo p² supplies the deformation class of the canonical lift, which is not the datum that κ depends on, and it is not even a fine invariant when AB = 0; the Serre–Tate route needs an étale p-torsion basis over F_{p^k} with k the order of t mod p, and its conversion into the Weierstrass basis is the Verschiebung kernel sum, i.e. κ again. The Maiga–Robert canonical-lift theorems exclude F_p inputs by hypothesis.

## 1. Input contract and conventions

The input is a certified prime p ≥ 7, a nonsingular short model E: y² = F(x) = x³+Ax+B over F_p, and its certified signed trace t with p ∤ t. Put h = (p−1)/2, H = [x^{p−1}]F^h = t mod p, β = [x^{p−2}]F^h and κ = β/H. The basis is ω = dx/y, η = x dx/y, read as classes in H¹_dR(E/F_p) through the low-pole Čech–de Rham convention of the extension note (§3.2 there), which is the reduction of the standard basis of H¹_dR of an integral Weierstrass model. Frobenius acts by pullback, written in the column convention φ\*(ω,η) = (ω,η)M. Over F_p the absolute Frobenius of E coincides with the F_p-Frobenius endomorphism π, because E is defined over F_p and σ is the identity on F_p and on Z_p. The unit-root line modulo p is ⟨[η] − κ[ω]⟩ = ker 𝒞_dR = Im F\* (Katz, 2019, §3; extension note §3.3–3.4). Under (A,B) ↦ (d²A, d³B), κ ↦ dκ; Aκ/B is invariant for AB ≠ 0.

Field-operation counts are in F_p or Z/p^N. Bit costs multiply by M(log p) or M(N log p) for one multiplication. Precision means the p-adic modulus p^N; extension degree k means work in F_{p^k}, whose operations cost Õ(k) F_p-operations.

## 2. Theorem A: the Frobenius matrix modulo p

**Theorem A.** Let p ≥ 7 and let E: y² = x³+Ax+B be nonsingular over F_p (ordinary or supersingular). In the basis ([ω],[η]) of H¹_dR(E/F_p), with the column convention,

$$F^*=\pi^*=\begin{pmatrix}0&-\beta\\0&t-p\end{pmatrix}\equiv\begin{pmatrix}0&-\beta\\0&H\end{pmatrix}.$$

Equivalently, for any integral Weierstrass lift with its crystalline identification H¹_cris(E/Z_p) ≅ H¹_dR(Ẽ/Z_p), the matrix of crystalline Frobenius in the lifted low-pole basis reduces to this M̄. When H ≠ 0 its image is ⟨−βω + Hη⟩ = ⟨η − κω⟩, so κ = −b₀/d₀ with b₀ = −β and d₀ = H.

*Proof.* The endomorphism α = π − 1 is separable, since α\*ω = π\*ω − ω = −ω and π\*ω = 0 in characteristic p. Its kernel is G = E(F_p), an étale group of order N = p+1−t. Write α = ι∘φ_G, where φ_G is Vélu's normalized isogeny (φ_G\*ω′ = ω) onto the Vélu model (A′,B′), and ι(x′,y′) = (x′/u², y′/u³) is an isomorphism onto (A,B). Then α\*ω = uω, so u = −1 and (A′,B′) = (u⁴A, u⁶B) = (A,B).

Vélu's x-map is x∘φ_G = x + Σ_{Q∈G∖O}(τ_Q\*x − x(Q)). Multiplying by ω = φ_G\*ω′ gives, as meromorphic forms, φ_G\*η′ = Σ_{Q∈G} τ_Q\*η − σ_G ω with σ_G = Σ_{Q∈G∖O} x(Q). Translations act trivially on H¹_dR of an elliptic curve in any characteristic, because H¹ classes are primitive (m\* = pr₁\* + pr₂\* on H¹) and their restriction to a point fibre vanishes. Every summand has double poles with residue zero and local primitives of pole order one, which is below p, so the low-pole convention is respected and the identity holds for classes: φ_G\*[η′] = N[η] − σ_G[ω]. With ι\*η = η′/u this gives

$$\alpha^*=\begin{pmatrix}u&-\sigma_G/u\\0&N/u\end{pmatrix}=\begin{pmatrix}-1&\sigma_G\\0&-N\end{pmatrix},\qquad \pi^*=\alpha^*+I=\begin{pmatrix}0&\sigma_G\\0&1-N\end{pmatrix}.$$

This is the matrix of Lemma 2 in the extension note. That lemma was stated for |G| prime to p; the argument above uses only Vélu's x-map and translation invariance, which hold for any étale kernel.

It remains to compute σ_G. Counting the points over each x, Σ_{Q∈G∖O} x(Q) = Σ_{x∈F_p} x(1+χ(F(x))) = Σ_x x F(x)^h in F_p, because Σ_x x = 0 and χ(z) = z^h. Since Σ_{x∈F_p} x^m equals −1 when m > 0 and (p−1) | m and is 0 otherwise, and deg(xF^h) = (3p−1)/2 < 2(p−1), only the term x^{p−1} survives: σ_G = −[x^{p−2}]F^h = −β. Finally 1 − N = t − p ≡ t ≡ H. ∎

A second, purely cohomological argument gives the same matrix. F\*[ω] = 0 because F\* kills differentials. F\*[η] is represented by the pure Čech cocycle (0,0,g^p), where g is the local primitive of η at O. Its η-coordinate is fixed by its image in H¹(E,𝒪); Serre duality with ω and Res_O(𝒞θ) = Res_O(θ)^{1/p} give d₀ = H. Its ω-coordinate is fixed by the requirement that the image of F\* lies in ker 𝒞_dR, i.e. 𝒞(b₀ω + d₀η) = b₀H + d₀β = 0, so b₀ = −β whenever H ≠ 0. That route uses the classical identification Im F\* = ker 𝒞_dR (Katz, 2019, §3, citing Katz, 1970); the Vélu proof does not.

**The low-pole convention is essential.** In characteristic p the Čech primitive of η at O is not unique: replacing the low-pole primitive g = 2x²/y by g + s(x²/y)^p leaves the differential η − dg unchanged but replaces [η] by [η] + (s/2)F\*[η], a shift along the conjugate line, and then the (1,2) entry changes. Theorem A is a statement about the basis whose primitives have pole order below p, which is the reduction of the integral basis. This is the extension note's §3.2 warning written as a matrix statement. In the row convention the matrix is the transpose [[0,0],[−β,H]].

An independent verification pass, written without access to this note's code, confirmed Theorem A by two methods that use neither Vélu's formulas nor point sums. A direct Čech–de Rham computation over the cover E∖O, E∖{y=0} with primitive 2x²/y matched every nonsingular model for 7 ≤ p ≤ 23 (1,418, supersingular included) and 30 random models at each of p = 29, 31, 37, 41. A Kedlaya–Monsky–Washnitzer computation of the integral Frobenius matrix gave integral matrices with trace t and determinant p modulo p², and reduction [[0,−β],[0,H]], on every model for p ≤ 23, 25 random models at p = 29, 31, 37, all p = 7 models modulo p³, and random integral lifts at p = 7, 11, 13.

**Corollary A.1 (smallest fragment and precision).** The entry b₀ of crystalline Frobenius modulo p is −β. Precision p suffices and is necessary for κ mod p; the matrix modulo p is intrinsic to E/F_p and is independent of the lift used to realize it. Supplying M̄, or supplying b₀ together with t, is a β-oracle. Extracting κ from it costs one inversion and one multiplication.

The same formula covers the supersingular case: M̄ = [[0,−β],[0,0]] with β ≠ 0 (Katz's no-common-zero statement), so the image of F\* is ⟨ω⟩, the conjugate filtration coinciding with the Hodge line. This is a consistency check, not part of the target.

**Relation to the p-adic E₂ literature.** Mazur, Stein and Tate (2006, §3.2) and Harvey (2008, §3) express the p-adic E₂ through the second column of a power of the Frobenius matrix on {dx/y, x dx/y}: with F^N(η) = a_Nω + b_Nη, E₂(E,ω_std) ≡ −12a_N/b_N mod p^N, where ω_std = dx/(2y + a₁x + a₃) is dx/(2y) on a short model. Read in the column convention (the only reading compatible with Katz, since the row reading makes the numerator vanish modulo p), Theorem A gives

$$E_2\bigl(E,\,dx/(2y)\bigr)\equiv12\kappa\pmod p,\qquad\text{equivalently}\quad E_2(E,\,dx/y)\equiv3\kappa .$$

The same relation follows from Katz (2019, Theorem 3.1), which states a_p ≡ E_{p−1} and b_p ≡ E_{p+1}/12 for y² = 4x³ − g₂x − g₃ with differential dx/y. Putting y = 2y′ turns our model into Katz's with the same x, a_p = 4^h H = H and b_p = β, and dx/y_Katz = dx/(2y′). This conversion is my inference and the independent pass reached it separately; it was not checked numerically against an independent E₂ computation. Harvey's Theorem 1 computes E₂ mod p^N in Õ(pN²) time, and in Õ(p^{1/2}N^{5/2}) when p > 6N. That is the published square-root comparator for the whole unit-root direction, not merely for κ.

## 3. Recovery maps from lift data

**Proposition B (any lift).** Let Ẽ/Z_p be any short Weierstrass model whose reduction is (A,B), with E ordinary. Let C = Ẽ[p]⁰ be its canonical subgroup (the points of Ẽ[p] reducing to O) and σ_C = Σ_{Q∈C∖O} x(Q) ∈ Z_p. Then σ_C ≡ 0 (mod p) and

$$\kappa\equiv\sigma_C/p\pmod p.$$

Moreover the closing scale u of Ẽ → Ẽ/C onto a model reducing to (A,B) satisfies u/p ≡ ±1/t (mod p).

*Proof.* The quotient ψ: Ẽ → Ẽ/C reduces to the relative Frobenius of E up to an isomorphism, because C reduces to the Frobenius kernel. Choose ι of scale u from the Vélu model of Ẽ/C onto a model Ẽ′ reducing to (A,B); then ψ′ = ι∘ψ lifts ±F. The Vélu argument of Theorem A, run over Z_p with |C| = p, gives the matrix V = [[u, −σ_C/u],[0, p/u]] from H¹_dR(Ẽ′) to H¹_dR(Ẽ). Crystalline Frobenius in the basis of Ẽ is M = V T, where T is the crystalline transport H¹_dR(Ẽ) → H¹_dR(Ẽ′) between two lifts of the same curve. T is the Taylor series of the Gauss–Manin connection with divided powers, so it is integral and T ≡ I (mod p) for p ≥ 3. Since M is integral, V is integral, and since d₀ = p/u is a unit by Theorem A, v(u) = 1 and v(σ_C) ≥ 1. Reducing, M̄ = V̄ = [[0, −σ_C/u],[0, p/u]]. Theorem A gives p/u ≡ ±t and −σ_C/u ≡ ∓β, hence κ = (σ_C/u)/(p/u) = σ_C/p. The sign is the [−1] ambiguity in ι and cancels in the ratio. ∎

The canonical lift is therefore unnecessary for this identity. What is necessary is the lifted p-isogeny, i.e. the kernel sum of C, to precision p²: σ_C/p = −2G₁/(pG₀) when the canonical factor G(s) = Π(s − 1/x(Q)) of the reversed p-division polynomial is written G₀ + G₁s + ⋯ with v(G₀) = 1, so G₁ is needed modulo p³ and G₀ modulo p². The next p-adic digit of σ_C/p does depend on the lift: in the pilot it differed between the trivial and a random lift in 515 of 570 models.

**Proposition C (canonical lift).** If Ẽ = E_can, then ψ′ = π_can is the Frobenius-lifting endomorphism, u = λ̄ = p/λ with λ the unit root of X² − tX + p, and the unit-root line is U = ⟨η + cω⟩ with

$$c=\frac{\sigma_C}{\bar\lambda^2-p}\in\mathbb Z_p,\qquad c\equiv-\kappa\pmod p.$$

This is Corollary 2.1 of the extension note read p-adically: U is the eigenline of π_can\* for the unit eigenvalue p/u = λ. For CM curves defined over Q at split primes the rational model is the canonical lift, and the pilot reproduces the known CM eigenline coordinate exactly: c ≡ 1 (mod p³) for (−35,−98) at p = 11, 23 and c ≡ −1 (mod p³) for (−30,56) at p = 11, 17, 19, matching β/H = −r and β/H = r of the reviewed −7 seed and −8 control. In the same runs u² = (p/λ)² to the working precision.

**Proposition D (étale side, characteristic p).** For ordinary E/F_p,

$$\beta=-\sum_{P\in E(\mathbb F_p)\setminus O}x(P),\qquad \kappa=-\frac{\sigma_V}{t^2},\quad \sigma_V=\sum_{Q\in E[p](\overline{\mathbb F}_p)\setminus O}x(Q).$$

The first identity is the last step of the proof of Theorem A (Katz, 2019, §6, has the equivalent character sum; the extraction lost its minus sign). For the second, apply the eigen-equation of the extension note (Theorem 1) to the Verschiebung π̂ = t − π, which is separable with kernel the étale p-torsion. Its Vélu matrix is [[t, −σ_V/t],[0, p/t]] ≡ [[t, −σ_V/t],[0,0]], while π̂\* = tI − M̄ = [[t, β],[0, t−H]]; comparing the (1,2) entries gives β = −σ_V/t. Concretely ψ_p ≡ c·ψ_V^p in F_p[x], ψ_V is the Verschiebung kernel polynomial of degree h, and σ_V = −2[x^{h−1}]ψ_V for monic ψ_V. For t = 1 (anomalous curves) both identities coincide, because E(F_p) = E[p](F̄_p).

**Proposition E (derivative form).** As polynomials over F_p in (A,B),

$$\beta\equiv\vartheta H,\qquad \vartheta=6B\,\partial_A-\tfrac43A^2\,\partial_B,\qquad\text{so }\kappa=\vartheta\log H .$$

*Proof.* Since ϑF = 6Bx − (4/3)A² and one checks the polynomial identity 6xF − ((4/3)A + 2x²)F′ = 6Bx − (4/3)A², the derivation rule gives ϑ(F^h) = hF^{h−1}ϑF = 6h·xF^h − ((4/3)A + 2x²)(F^h)′. Taking the coefficient of x^{p−1}, and using [x^{p−1}](F^h)′ = p[x^p]F^h and [x^{p−3}](F^h)′ = (p−2)β, gives the exact identity over Z[1/3]

$$\vartheta H=(p+1)\,\beta-\tfrac{4p}{3}A\,[x^p]F^h ,$$

so ϑH ≡ β (mod p). ∎ This short proof was found by the independent verification pass, which checked the exact identity for every p from 5 to 71. My original proof eliminates the coefficients e_n = [x^n]F^{h−1}: the vanishing of x^{p−1}-coefficients of (x^kF^h)′ for k = 0, 1, 2 gives 3e_{p−3} = −Ae_{p−1}, H = 2Ae_{p−2} + 3Be_{p−1} and β = −2Ae_{p−3} − 3Be_{p−2} (using h ≡ −1/2), hence β = (2/3)A²e_{p−1} − 3Be_{p−2} = 6B∂_AH − (4/3)A²∂_BH, since ∂_AH = he_{p−2} and ∂_BH = he_{p−1}.

The second relation is Euler's identity 4A∂_AH + 6B∂_BH = −H for the weight p−1 ≡ −1. So the scaling direction carries no new information, and κ is exactly one transverse derivative of the Hasse invariant along the moduli. A certified trace supplies H only at the point; the eight same-trace, distinct-slope pairs show that the value does not determine the derivative. In Katz's chart this is the familiar fact that b_p ≡ E_{p+1}/12 ≡ ∂E_{p−1} for the Serre derivative ∂, since E_{p−1} ≡ 1 and E₂ ≡ E_{p+1} as q-expansions; that interpretation is an inference from Katz (2019) and is not used in the proof.

## 4. Information audit

| Offered object | Precisely what it is | Determines κ? | Recovery map | Status |
|---|---|---|---|---|
| Certified trace t | One integer; H = t mod p | No | None: eight exact same-trace pairs with distinct κ | Classical value datum |
| Unit-root eigenvalue λ mod p^k | Root of X²−tX+p, Hensel from t | No | Same pairs | Eigenvalue, not eigenline |
| j_can mod p² | Witt coordinate j₁ of the canonical lift | Not by any identified map | For AB ≠ 0 it fixes E_can mod p² up to an isomorphism ≡ id mod p; κ is lift-independent (Prop. B) and still needs C | Insufficient as a recovery datum; for AB = 0 not even a fine invariant |
| Marked integral Weierstrass lift | Any (Ã,B̃) reducing to (A,B); trivial lift is free | No, alone | With C: κ = σ_C/p | Not the bottleneck |
| Lifted p-isogeny / canonical subgroup | C = Ẽ[p]⁰ and σ_C mod p² | Yes | κ = σ_C/p (Prop. B) | Oracle; σ_C/p ≡ κ |
| Frobenius lift π_can on E_can | Endomorphism lifting π | Yes | c = σ_C/(λ̄²−p) (Prop. C) | Oracle |
| Serre–Tate parameter with markings | q ∈ 1+pZ_p from étale and multiplicative bases | No, alone | Locates E_can (q = 1), which is not needed | Conversion needs σ_V (Prop. D) |
| Étale p-torsion point / Verschiebung kernel | Point over F_{p^k}, k = ord(t mod p); ψ_V of degree h | Yes | κ = −σ_V/t² | Oracle; data Θ(p) |
| Crystalline Frobenius matrix in this basis | M mod p | Yes | κ = −b₀/d₀, b₀ = −β | Oracle; contains β |
| Fixed-D exact CM table | R_D(j) for small fixed D | Yes for members | β/H = −(3B/2A)R_D(j) | Completed restricted case |
| Transverse derivative of H | ϑH at (A,B) | Yes | κ = ϑH/H (Prop. E) | Needs H as a polynomial (Θ(p) monomials) |

The j-line is ramified at 0 and 1728, which is why j_can mod p² fails there. Every lift (pa₁, B) of an A = 0 curve has j ≡ 0 (mod p³), although the lift-to-Z/p² classes are indexed by a₁ up to μ₃ and only a₁ = 0 is canonical; the deformation first appears as a₁³ in j mod p⁴. For B = 0, every (A, pb₁) has j ≡ 1728 (mod p²). The pilot confirms both on 69 lifts, and confirms that the Deligne–Tate image of every such lift is canonical modulo p². In these two cases κ = 0 by the automorphism argument, so the failure costs nothing for the slope, but it shows that "j_can mod p² determines the canonical lift" is false without AB ≠ 0.

## 5. Dependency and cost table

Costs below are for one curve, p growing, and are stated as field operations; bit costs multiply by M(log p) (or M(N log p) at precision N). "Cold" includes every prime-dependent table; "cached" assumes the table already exists for that prime.

| Route/object | Assumptions | Exact construction | Size | Cold cost | Cached cost | Reconstruction/basis cost | Independent check | Status |
|---|---|---|---|---|---|---|---|---|
| Comparator: BGS on c_n | B ≠ 0; unit conditions of BGS Thm 14 (B(n+1) invertible for n+1 < p) | Order-3 recurrence B(n+1)c_{n+1} = (h−n)Ac_n + (3h−n+2)c_{n−2} evaluated at n = p−2 | O(√p) words | Õ(√p) | Same | O(1) | Recurrence implemented directly (O(p)) and matched to targets | Theoretical bound; no generic native BGS backend is retained (the retained native kernels serve the historical fifth-point and quarter recurrences) |
| Comparator: Harvey (2008) | p > 6N | Kedlaya-type Frobenius on {dx/y, x dx/y} | O(√p) | Õ(p^{1/2}N^{5/2}) | Same | O(1) via Theorem A | Not implemented | Published bound; parity class |
| Theorem A oracle | M̄ supplied | Read (1,2) and (2,2) entries | 2 elements | Charged to supplier | O(1) | κ = −b₀/d₀ | Three routes in pilot | Oracle reduction |
| j_can mod p² via Erdoğan–Finotti J₁ | AB ≠ 0; ordinary | Universal rational function J₁ ∈ F_p(X), poles only at supersingular j | Θ(p) coefficients (Finotti: denominator involves ss_p(X)², numerator from Φ_p(X,X^p)/p) | Θ(p) table; via Φ_p, Θ(p³ log p) bits | Θ(p) per evaluation (Horner) | No identified map to κ | Not computed | Obstruction: data size, and no recovery map |
| j_can mod p² via CM | End(E) of discriminant D found and certified | Root of H_D modulo p² | h(D) ≍ √\|D\| coefficients of size Õ(√\|D\|) | Õ(\|D\|) (CRT method, GRH; not re-verified here) plus order discovery | O(h(D)) | No identified map to κ | H_D(j_can) ≡ 0 mod p³ on 74 retained-table curves | Obstruction for generic \|D\| ≍ p |
| j_can mod p² via Satoh/Maiga–Robert Newton | j ∉ F_{p²} | Newton on Φ_p(J,J^σ) | — | — | — | — | — | Hypothesis failure: j ∈ F_p, and Φ_p(X,X) ≡ −(X^p−X)² has a double root at every j ∈ F_p |
| Maiga–Robert Thm 1.2 | j ∉ F_{p²}; rational étale p-torsion point given | Isogeny evaluation of degree p | — | Õ(mn log p + I(p,m,Z_q)), with I = Õ(pmn) by Vélu or Õ(√p·mn) by the cited improvement | — | Outputs E_can and trace, not κ | — | Hypothesis failure; even formally the isogeny term is square-root scale at best, and a rational étale point over F_p exists only for t = 1 |
| Canonical subgroup σ_C (any lift) | Ordinary | Slope-1/(p−1) factor of the [p]-series or of the reversed ψ_p, precision ≥ p³ | Kernel factor: h coefficients × 3 digits; inputs Θ(p) (formal group to degree ≈ 2p) or Θ(p²) (ψ_p) | Θ(p)–Θ(p²) in identified constructions | Same | κ = σ_C/p, O(1) | 570 models, trivial/random/canonical lifts | Oracle proved; data-size obstruction; σ_C/p ≡ κ (circular) |
| Deligne–Tate canonical lift | Ordinary, AB ≠ 0 | Iterate Ẽ ↦ Ẽ/C; one step gives j_can mod p² | As above per step | As above × precision | — | Gives j_can, not κ | 720 convergence checks; CM j recovered from random lifts | Same obstruction; no κ gain |
| Serre–Tate coordinate | Ordinary; markings | Étale point P ∈ E(F_{p^k}), k = ord_p(t) dividing p−1; μ_p side over Z_p[ζ_p] | Θ(k log p) bits for P | Õ(k² log p) to find P from #E(F_{p^k}) | — | Conversion to (ω,η) is σ_V: Θ(p) points over F_{p^k} | Not built | Obstruction: k is typically Θ(p); conversion circular |
| Verschiebung kernel σ_V | Ordinary | ψ_V from ψ_p (char p) or from P | h coefficients | Θ(p²) via ψ_p; Θ(kp) from points | — | κ = −σ_V/t² | 1,395 models | Oracle proved; data-size obstruction |
| t = ±1 subclass | t = ±1, so k ≤ 2 | P rational (t = 1) or quadratic (t = −1) | O(log p) for P | polylog for P | — | σ_V = Σ_{k<p} x(kP): Θ(p) naive; Õ(√p) by a baby-step/giant-step adaptation of √élu (inference, not implemented) | 76/77 rows | Parity at best; not a restricted improvement |
| π − 1 point sum | — | Σ x over E(F_p) | p points | Θ(p) | — | β directly | 1,574 models incl. p up to 2·10⁴ | Equivalent coefficient; BSGS parity if E(F_p) cyclic |
| Generic endomorphism (Thm 1) | Separable non-scalar α, separated eigenvalues | Kernel sum of α | deg α ≥ \|D\|/4 | Θ(\|D\|)-scale; kernels over extensions | — | β/H = σ/(ℓ−u²) | Fixed-D work | Restricted to small \|D\|; generic \|D\| ≍ p |
| Serre derivative ϑH | — | ∂_AH, ∂_BH | Θ(p) monomials | Θ(p) | Θ(p) per point | κ = ϑH/H | 19,948 models | Equivalent to β; no derivative oracle from point counting |

A per-prime cache of the slope for every j ∈ F_p (Θ(p log p) bits, built in Õ(p) or worse) makes later queries O(1) plus a chart conversion. That is a cached-query contract, not a cold single-curve algorithm, and it is not credited here.

## 6. Why each named route stops

The precision-p² canonical-lift route stops for two independent reasons. First, no recovery map from j_can mod p² alone was found, and Proposition B shows why one should not expect a natural one. Lifts of E to Z/p² correspond to lifts of the Hodge line in H¹_cris(E/(Z/p²)), and the canonical lift is the one whose Hodge line is Frobenius-stable (classical, via Grothendieck–Messing; not re-read in this pass). Relative to a reference lift that is a condition on the (2,1)-entry of the Frobenius matrix modulo p², whereas κ sits in the (1,2)-entry, which is lift-independent modulo p. The extra datum that converts a lift into κ is the kernel sum of its canonical subgroup, and that datum works for every lift. Second, every identified construction of j_can mod p² for j ∈ F_p uses Θ(p)-size prime-dependent data or a growing CM discriminant, and the Newton route fails its hypothesis. Under the stopping rule this route is closed for this study.

The Serre–Tate route stops because setting q = 1 only identifies the canonical lift, which Proposition B makes unnecessary, and because converting the étale-side splitting into the Weierstrass basis is precisely Proposition D's Verschiebung kernel sum. That sum is equivalent to κ given t, and constructing it needs p − 1 points over F_{p^k}, with k the multiplicative order of t mod p. For t = ±1 the point is cheap, but the sum is not; the best identified device is a baby-step/giant-step sum of the √élu type, which is again square-root scale.

These are barriers to the explicit constructions named, not lower bounds. A sub-square-root formula for σ_C, σ_V or ϑH at a point would be a new algorithm for κ, and nothing here excludes one.

## 7. Source audit

| Source | Version and access in this pass | What was verified | Inference added here |
|---|---|---|---|
| Katz, N. M. (2019). On a question of Zannier. *Experimental Mathematics*. doi:10.1080/10586458.2018.1551818 (author PDF) | Fetched twice; text extraction drops minus signs and some symbols | Theorem 3.1 (a_p ≡ E_{p−1}, b_p ≡ E_{p+1}/12; no common zero); 𝒞(dx/y) = a_p dx/y, 𝒞(x dx/y) = b_p dx/y; Im Frob = ker 𝒞 citing Katz (1970); for ordinary E, U is spanned by x dx/y − (b_p/a_p) dx/y; §6 character sums; Weierstrass chart y² = 4x³ − g₂x − g₃ with g₂ = E₄/12 | The §6 sums came through without signs; numerically only a_p ≡ −Σχ(f(t)) and b_p ≡ −Σtχ(f(t)) hold (independent pass, all models p ≤ 31), as our derivation predicts; the chart conversion is ours |
| Katz, N. M. (1976). p-adic interpolation of real analytic Eisenstein series. *Annals of Mathematics*, 104(3), 459–571 (author scan) | Fetched; extraction covers pp. 459–506 only | §1.3 and Lemma 4.0.7 readable with OCR noise | §5.7, Theorem 8.0.9 and Lemma 8.0.13 were not reachable; not cited for any step |
| Erdoğan, A. A universal formula for the j-invariant of the canonical lifting. arXiv:1211.1152v4 (8 April 2013) | Fetched | Theorem 1.1: Witt coordinates are f_i ∈ F[J, 1/φ_p(J)]; ordinary j = 0, 1728 lift to themselves; no degree bounds, no explicit j₁, no complexity statement | Cost of evaluating f₁ argued from Finotti's description, not from Erdoğan |
| Finotti, L. R. A. Lifting the j-invariant: questions of Mazur and Tate (author manuscript) | Fetched; no journal data printed | J₁ ∈ F_p(X); regular at 0 and 1728; poles at other supersingular j; formula via Φ_p(X,X^p)/p; reported reliance on Kaneko–Zagier for a closed form with ss_p(X)² | Θ(p) size of J₁ inferred from these descriptions; publication venue not verified |
| Borger, J., & Gurney, L. Canonical lifts of families of elliptic curves. arXiv:1608.05912v1 | Fetched; no date printed in PDF | Existence and uniqueness of canonical lifts over W(S) with a Frobenius lift; §7.3 j₁ = (ψ(j) − j^p)/p; no algorithm or complexity claim | None |
| Maiga, A., & Robert, D. Towards computing canonical lifts of ordinary elliptic curves in medium characteristic (author manuscript, no date printed) | Fetched twice (here and by the independent pass) | Thm 1.1 assumes j(E) ∉ F_{p²}, cost Õ(mnp); Thm 1.2 additionally assumes a given rational étale p-torsion point, cost Õ(mn log p + I(p,m,Z_q)), with I = Õ(pmn) by Vélu and Õ(√p·mn) by a cited later improvement; Cor. 1.4 Õ(p log²q + √p m e log q) with e the degree of the field of étale p-torsion; §2.3 Kronecker congruence and Verschiebung kernel factor H_p; Lemma 5.2 characterizes j_can mod p² by Ψ_{Ẽ,p}(P) ≡ 0 mod p² under the paper's hypotheses; no treatment of j ∈ F_p | The exclusion of every E/F_p follows from F_p ⊂ F_{p²}; that is an inference, not a statement in the paper |
| Bostan, A., Gaudry, P., & Schost, É. (2007). *SIAM J. Comput.*, 36(6), 1777–1806 | SIAM version paywalled; author versions fetched (preprint dated 12 Sep 2006) | Theorem 14: N-th term of U_{i+1} = M(i+1)U_i (n×n, degree ≤ 1) in O(MM(n)√N + n²M(√N)) operations and space O(n²√N), given that small powers of 2 up to 2^{s+1} (s = ⌊log₄N⌋) are units and certain inverses are supplied; Theorem 17: Hasse–Witt matrix, essentially Õ(√p) for fixed genus | Typeset theorem numbering not checked against the journal; application to the order-3 recurrence for c_n is ours |
| Mazur, B., Stein, W., & Tate, J. (2006). Computation of p-adic heights and log convergence. *Documenta Math.*, Extra Vol. Coates, 577–614 | Fetched (author copy) | §3.2: with F^n(η) = a_nω + b_nη, b_n a unit and E₂(E,ω) ≡ −12a_n/b_n mod p^n; U mod p^n spanned by F^n(η); E₂E_{p−1} ≡ E_{p+1} mod p stated as well known | Chart conversion is ours: on y² = 4x³ − g₂x − g₃ with dx/y this gives E₂(E, dx/(2y)) ≡ 12κ in our chart (§2); not checked against an independent E₂ computation |
| Harvey, D. (2008). Efficient computation of p-adic heights. *LMS J. Comput. Math.*, 11, 40–59 (arXiv:0708.3404) | Fetched (arXiv) | Theorem 1: E₂ mod p^N in Õ(pN²), and Õ(p^{1/2}N^{5/2}) if p > 6N; E₂ = −12B/D for F^N = [[A,B],[C,D]] on {dx/y, x dx/y} | Journal data and DOI from the publisher page; the independent pass read ω = dx/(2y + a₁x + a₃) and inferred the column convention from Harvey's remark that Kedlaya's algorithm computes the two columns independently |
| Bernstein, D. J., De Feo, L., Leroux, A., & Smith, B. (2020). Faster computation of isogenies of large prime degree. arXiv:2003.10118 | Abstract fetched | Õ(√ℓ) F_q-operations for an ℓ-isogeny given a rational kernel point of prime order ℓ | Adaptation to kernel sums Σx(kP) is an unimplemented inference |
| Vélu, J. (1971). Isogénies entre courbes elliptiques. *C. R. Acad. Sci. Paris Sér. A*, 273, 238–241 | Not re-read; formulas A′ = A − 5t, B′ = B − 7w used and tested | Codomain formulas validated numerically (π−1 codomain, canonical-subgroup scale checks) | — |

## 8. Validation (observed output)

All scripts use the Python standard library only and ran under Python 3.13.16 on Linux (x86-64, glibc 2.39). The handover verifier passed (67 files) and the handover reference controls reproduced byte-identical CSV and JSON outputs; only the environment fields differ. The retained CM context unpacked with the completed D = −256 recognizer present. The pilot imports the retained `fixed_D_evaluator.py` (path and SHA-256 recorded in `padic_summary.json`) and records the hashes of the completed `depth_three_recognize.py` and `depth_three_b0_recognize.py`; the recognizers themselves were not executed, so the old-comparator mismatch cannot arise here.

| Check | Scope | Result |
|---|---|---|
| Independent β via the order-3 recurrence vs handover targets | 1,256 ordinary models, p ≤ 23 | 0 disagreements |
| Theorem A via π−1: Σ_{E(F_p)} x = −β and Vélu codomain (A,B) | 1,574 ordinary models: exhaustive p ≤ 23, 80 each at p = 29, 31, three each at 60 primes in [1000, 20000] | PASS |
| Proposition D: κ = −σ_V/t² from ψ_p ≡ cψ_V^p | 1,395 ordinary models (p ≤ 31) | PASS |
| Twist law on the Verschiebung route | 1,256 models | PASS |
| Supersingular: ψ_p mod p a nonzero constant | 193 models | PASS |
| Proposition E: β = ϑH and Euler relation | 19,948 nonsingular models, all p ≤ 61 | PASS |
| Proposition B, trivial lift | 570 ordinary models: exhaustive p ≤ 17, 40 at p = 19, 25 at p = 23 | PASS |
| Proposition B, random lift | Same 570 | PASS |
| Proposition B, canonical lift (three Deligne–Tate steps) | 240 models, p ≤ 13, AB ≠ 0 | PASS |
| Frobenius-lift scale (A′/p⁴)t⁴ ≡ A, (B′/p⁶)t⁶ ≡ B | 570 | PASS (d₀ = ±t) |
| u² = (p/λ)² at the iterated canonical lift | 240, mod p² | PASS |
| Retained fixed-D slopes vs targets, and H_D(j_can) ≡ 0 mod p³ | 74 curves | PASS |
| CM-over-Q canonical lifts (j ∈ {0, 1728, −3375, 8000, −32768, 54000, 287496, −884736, −12288000, 16581375, −884736000}) | 29 prime/curve pairs | κ = σ_C/p; c ≡ 1 (D = −7) and c ≡ −1 (D = −8) mod p³; Deligne–Tate maps a random lift to j_CM mod p² |
| AB = 0 insufficiency of j mod p² | 69 lifts at p = 7, 13, 19 (A = 0) and 13, 17 (B = 0) | j constant mod p³ (resp. p²) across non-isomorphic lifts; κ_C = 0; DT image canonical |
| Original cubic (H, K, T) from the lift-route κ only | 507 cubics, 387 branch queries, p ≤ 13 | Equal to dense f^h strict-prefix sums |
| Same-trace distinct-slope pairs | 8 handover pairs | Lift route reproduces both slopes |
| Coverage labels | Char p: 1,297 outside-table, 76 with t = 1, 77 with t = −1, 42 with A = 0, 34 with B = 0; p-adic: 381, 30, 34, 19, 28 | Outside-table is a label, not a non-CM claim |
| Failure injection | One wrong constant in each of three scripts | Each exits 1 with a FAIL line; `run_all.py` exits 1 |
| Independent pass, Theorem A by Čech cocycles | All 1,418 nonsingular models p ≤ 23; 30 random at each of p = 29, 31, 37, 41 | Matches [[0,−β],[0,H]] |
| Independent pass, Theorem A by Kedlaya–Monsky–Washnitzer | All models p ≤ 23 (mod p²), 25 random at p = 29, 31, 37, p = 7 mod p³, random lifts at p = 7, 11, 13 | Integral; trace t; det p; reduction matches |
| Independent pass, Proposition B via the formal-group [p]-series | 1,026 model–lift pairs, p = 7 to 23, trivial and random lifts | σ_C ≡ 0 and σ_C/p ≡ κ (mod p); higher digits lift-dependent (e.g. p = 7, (5,6): σ_C/p ≡ 234, 325, 115, 199 mod 343 for four lifts, all ≡ κ = 3) |
| Independent pass, Proposition D with explicit étale points in F_{p^k} | All 1,256 ordinary models p ≤ 23, k up to 22 | κ = −σ_V/t² |
| Independent pass, Propositions D(i) and E | p ≤ 61 and the exact ϑ-identity for 5 ≤ p ≤ 71 | Confirmed |

No timing benchmark was run. No candidate algorithm survived, so the benchmark condition of the assignment (complete output agreement of a cheaper method) never arose. The verification route used here builds the p-division polynomial of degree (p²−1)/2 and is far slower than the O(p) reference; it is an oracle construction for checking identities.

## 9. Status separation

**Classical facts used.** Crystalline Frobenius reduces to F\* on H¹_dR and is lift-independent modulo p; Im F\* = ker 𝒞_dR is the unit-root line modulo p (Katz, 1970, 2019). Translations act trivially on H¹_dR. Vélu's formulas hold for étale kernels. Canonical subgroups, the Deligne–Tate Frobenius lift E ↦ E/C and the canonical lift as its fixed point are standard (Katz's Serre–Tate local moduli and its descendants; not re-read). The CM curve over Q is the canonical lift of its ordinary reductions (Deuring).

**Proved in this note.** Theorem A with b₀ = −β, d₀ = H, for every nonsingular short model and p ≥ 7. Proposition B for arbitrary lifts. Proposition C as the p-adic reading of the extension note's Corollary 2.1. Proposition D, both identities. Proposition E with its three-relation proof. The AB = 0 failure of j mod p² as a fine invariant. These are unrefereed; the ingredients are classical, and novelty is not claimed.

**Tested prototypes.** The scripts in `ordinary_k_pilot/` validate the statements above on the stated finite scopes. They are not algorithms for κ and are slower than the O(p) reference. A separate verification pass (`independent_check/`), written without access to this note or its code, reproduced Theorem A by Čech cocycles and by a Kedlaya-type Frobenius computation, Proposition B through the formal group, Proposition D through explicit étale points, and proved Proposition E by a shorter exact identity. That pass tested, but did not independently prove, Propositions B and D; their proofs are the ones given here.

**Conjectural or inferential.** That a √élu-type baby-step/giant-step device computes Σx(kP) in Õ(√p) operations; that Finotti's J₁ has Θ(p) size in general; the reconciliation of E₂ normalizations across Katz, Mazur–Stein–Tate and Harvey with this chart.

**Corrected or failed approaches (preserved).** My first version of the π−1 check also required w_G ≡ 0; at p = 7, A = 0, B = 1 one has w_G ≡ 2 while B′ = B − 7w_G = B, because x³F^h reaches degree 2(p−1) only at p = 7. The check was corrected to compare Vélu codomains, which is what the theorem needs. The second p-adic digit of σ_C/p is lift-dependent (515 of 570 trivial/random comparisons differ), so only κ mod p is lift-invariant. The historical precision-two results (44 and 83 instead of 70 modulo 169 at p = 13, and the pole obstruction to the archived bounded-degree CM defect) were not touched and are not generalized.

## 10. In plain language

Think of each elliptic curve as having a hidden arrow, the slope κ. The handover asked whether the curve's "ideal p-adic twin" (its canonical lift) lets us read off that arrow cheaply. The answer found here is that we now know exactly where the arrow is written. It is one entry of the Frobenius matrix, and that entry is literally the coefficient we wanted. We also found four other places where the same arrow is written: in a sum over a special subgroup of any p-adic twin (not just the ideal one), in a sum over the curve's points, in a sum over its p-torsion, and as a derivative of the Hasse invariant. Every one of those places is as large as the original problem, about p items, unless one uses the same square-root trick we already have. So the twin does not give a shortcut for ordinary curves in general. It does give exact, checked formulas that would make any future shortcut easy to verify, and it rules out two tempting routes for concrete reasons.

## References

Bernstein, D. J., De Feo, L., Leroux, A., & Smith, B. (2020). *Faster computation of isogenies of large prime degree* (arXiv:2003.10118). arXiv. https://arxiv.org/abs/2003.10118

Borger, J., & Gurney, L. (2016). *Canonical lifts of families of elliptic curves* (arXiv:1608.05912v1). arXiv. https://arxiv.org/abs/1608.05912

Bostan, A., Gaudry, P., & Schost, É. (2007). Linear recurrences with polynomial coefficients and application to integer factorization and Cartier–Manin operator. *SIAM Journal on Computing, 36*(6), 1777–1806. https://doi.org/10.1137/S0097539704443793

Erdoğan, A. (2013). *A universal formula for the j-invariant of the canonical lifting* (arXiv:1211.1152v4). arXiv. https://arxiv.org/abs/1211.1152

Finotti, L. R. A. (n.d.). *Lifting the j-invariant: Questions of Mazur and Tate* [Author manuscript]. https://luisfinotti.org/math/papers/liftj.pdf

Harvey, D. (2008). Efficient computation of p-adic heights. *LMS Journal of Computation and Mathematics, 11*, 40–59. https://doi.org/10.1112/S1461157000000528 (arXiv:0708.3404)

Katz, N. M. (1976). p-adic interpolation of real analytic Eisenstein series. *Annals of Mathematics, 104*(3), 459–571. https://web.math.princeton.edu/~nmk/old/padicinterp.pdf

Katz, N. M. (2019). On a question of Zannier. *Experimental Mathematics*. https://doi.org/10.1080/10586458.2018.1551818 (year from the author PDF's copyright line; volume, issue and pages not verified)

Maiga, A., & Robert, D. (n.d.). *Towards computing canonical lifts of ordinary elliptic curves in medium characteristic* [Author manuscript]. https://www.math.u-bordeaux.fr/~damienrobert/pro/publications/articles/fast_canonical_lift_g1.pdf

Mazur, B., Stein, W., & Tate, J. (2006). Computation of p-adic heights and log convergence. *Documenta Mathematica, Extra Volume: John H. Coates' Sixtieth Birthday*, 577–614. https://www.williamstein.org/papers/pheight/pheight.pdf

Vélu, J. (1971). Isogénies entre courbes elliptiques. *Comptes Rendus de l'Académie des Sciences de Paris, Série A, 273*, 238–241.
